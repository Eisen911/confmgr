# Conference Management System - Setup Guide

## Quick Setup Instructions

### 1. Install Dependencies

```bash
# Install root dependencies
npm install

# Install client dependencies
cd client && npm install && cd ..
```

### 2. Setup PostgreSQL Database

```bash
# Create database
createdb conference_management

# Run schema
psql conference_management < database/schema.sql
```

### 3. Configure Environment

```bash
# Copy environment file
cp .env.example .env

# Edit .env with your settings
nano .env
```

**Required Environment Variables:**
- `DB_HOST=localhost`
- `DB_NAME=conference_management`
- `DB_USER=postgres`
- `DB_PASSWORD=your_password`
- `JWT_SECRET=your-secret-key`
- `EMAIL_USER=bigfatty@gmail.com`
- `EMAIL_PASSWORD=your-app-password`

### 4. Start Development Server

```bash
# Start both client and server
npm run dev

# Access the application
# Frontend: http://localhost:3000
# Backend: http://localhost:5000
```

## Email Setup (Important)

For email notifications to work, you need:

1. **Gmail Account** with 2FA enabled
2. **App Password** generated in Gmail settings
3. **App Password** used in `EMAIL_PASSWORD` environment variable

### Generate Gmail App Password:
1. Go to Google Account settings
2. Security → 2-Step Verification → App passwords
3. Select "Mail" → "Other (Custom name)"
4. Use generated password in `.env`

## Default Admin User

After setup, create an admin user by:
1. Registering through the web interface
2. Manually updating the database to give admin role
3. Or use the admin interface to assign roles

## Database Schema

The system includes comprehensive database schema with:
- User management with roles
- Conference and track management
- Paper submission system
- Review workflow
- Email notifications
- File management

## API Endpoints

### Authentication
- `POST /api/auth/register` - User registration
- `POST /api/auth/login` - User login
- `GET /api/auth/me` - Get current user

### Conferences
- `GET /api/conferences` - List conferences
- `POST /api/conferences` - Create conference (Admin)
- `GET /api/conferences/:id` - Get conference details

### Papers
- `GET /api/papers` - List papers
- `POST /api/papers` - Submit paper
- `GET /api/papers/:id` - Get paper details

### Reviews
- `GET /api/reviews/assignments` - Get review assignments
- `POST /api/reviews/assignments/:id/review` - Submit review

## File Structure

```
conference-management-system/
├── src/
│   ├── server/          # Backend (Node.js/Express)
│   │   ├── routes/      # API routes
│   │   ├── middleware/  # Auth & validation
│   │   ├── services/    # Business logic
│   │   └── database/    # DB connection
│   └── client/          # Frontend (React/TypeScript)
│       ├── src/
│       │   ├── components/  # UI components
│       │   ├── pages/       # Application pages
│       │   ├── contexts/    # React contexts
│       │   └── services/    # API services
├── database/
│   └── schema.sql       # Database schema
├── uploads/             # File storage
└── README.md           # Documentation
```

## Features Implemented

✅ **User Management**
- Registration and login with JWT
- Role-based access control
- User profiles and settings
- Password reset functionality

✅ **Conference Management**
- Create and configure conferences
- Set submission deadlines
- Manage conference tracks
- Conference status management

✅ **Paper Submission System**
- Submit papers with file uploads
- Track submission status
- Author dashboard
- Paper management

✅ **Review System**
- Assign reviewers to papers
- Complete reviews with criteria
- Blind review support
- Review tracking

✅ **Administrative Features**
- User management
- Conference analytics
- System configuration
- Review oversight

✅ **Email Integration**
- Welcome emails
- Password reset
- Review assignments
- Decision notifications

✅ **Security**
- Input validation
- SQL injection protection
- File upload security
- JWT authentication
- CORS configuration

✅ **UI/UX**
- Responsive design
- Modern interface
- Loading states
- Error handling
- Professional styling

## Next Steps

1. **Setup Database** - Run the schema.sql file
2. **Configure Environment** - Set up .env file
3. **Start Development** - Run `npm run dev`
4. **Test Features** - Create users, conferences, papers
5. **Customize** - Modify design, add features
6. **Deploy** - Move to production environment

## Troubleshooting

**Database Connection Issues:**
- Check PostgreSQL is running
- Verify database exists
- Check connection credentials

**Email Not Working:**
- Verify Gmail app password
- Check 2FA is enabled
- Verify environment variables

**Frontend Build Issues:**
- Clear node_modules and reinstall
- Check Node.js version (18+)
- Verify all dependencies

## Production Deployment

1. **Environment Setup**
   - Set NODE_ENV=production
   - Use secure JWT_SECRET
   - Configure production database

2. **Build Application**
   ```bash
   npm run build
   ```

3. **Deploy**
   - Use PM2 or similar process manager
   - Setup reverse proxy (nginx)
   - Configure SSL certificates

The system is production-ready with proper security, error handling, and scalability considerations.