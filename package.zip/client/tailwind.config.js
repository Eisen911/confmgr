/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        primary: {
          50: '#EBF4FF',
          500: '#007BFF',
          700: '#0056B3',
        },
        neutral: {
          50: '#F8F9FA',
          100: '#E9ECEF',
          500: '#6C757D',
          900: '#212529',
        },
        success: {
          500: '#28A745',
        },
        warning: {
          500: '#FFC107',
        },
        error: {
          500: '#DC3545',
        }
      },
      fontFamily: {
        sans: ['Inter', 'system-ui', 'sans-serif'],
      },
      fontSize: {
        'display': ['48px', { lineHeight: '1.2', fontWeight: '700' }],
        'h1': ['32px', { lineHeight: '1.3', fontWeight: '700' }],
        'h2': ['24px', { lineHeight: '1.4', fontWeight: '600' }],
        'h3': ['20px', { lineHeight: '1.4', fontWeight: '600' }],
        'body': ['16px', { lineHeight: '1.5', fontWeight: '400' }],
        'body-sm': ['14px', { lineHeight: '1.5', fontWeight: '400' }],
        'label': ['12px', { lineHeight: '1.4', fontWeight: '500' }],
      },
      spacing: {
        '8': '8px',
        '12': '12px',
        '16': '16px',
        '24': '24px',
        '32': '32px',
        '48': '48px',
        '64': '64px',
      },
      borderRadius: {
        'card': '16px',
        'button': '8px',
        'pill': '9999px',
      },
      boxShadow: {
        'md': '0 4px 12px rgba(0, 123, 255, 0.08)',
        'lg': '0 8px 24px rgba(0, 123, 255, 0.12)',
      },
    },
  },
  plugins: [],
}