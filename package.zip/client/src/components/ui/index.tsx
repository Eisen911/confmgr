import React from 'react'
import { cn } from '../../lib/utils'
import { getStatusColor, getStatusLabel } from '../../lib/utils'

interface CardProps {
  children: React.ReactNode
  className?: string
  hover?: boolean
  padding?: 'sm' | 'md' | 'lg'
}

interface StatusTagProps {
  status: string
  size?: 'sm' | 'md'
}

interface PageHeaderProps {
  title: string
  subtitle?: string
  actions?: React.ReactNode
  breadcrumbs?: Array<{ label: string; href?: string }>
}

const Card: React.FC<CardProps> = ({ 
  children, 
  className, 
  hover = false,
  padding = 'md'
}) => {
  const paddingClasses = {
    sm: 'p-4',
    md: 'p-6',
    lg: 'p-8'
  }

  return (
    <div 
      className={cn(
        'bg-white rounded-card shadow-md transition-all duration-250',
        hover && 'hover:shadow-lg hover:-translate-y-1',
        paddingClasses[padding],
        className
      )}
    >
      {children}
    </div>
  )
}

const StatusTag: React.FC<StatusTagProps> = ({ status, size = 'md' }) => {
  const statusColor = getStatusColor(status)
  const statusLabel = getStatusLabel(status)
  
  const sizeClasses = {
    sm: 'px-2 py-1 text-xs',
    md: 'px-3 py-1 text-sm'
  }

  return (
    <span className={cn(
      'status-tag rounded-pill font-medium',
      statusColor,
      sizeClasses[size]
    )}>
      {statusLabel}
    </span>
  )
}

const PageHeader: React.FC<PageHeaderProps> = ({ title, subtitle, actions, breadcrumbs }) => {
  return (
    <div className="mb-8">
      {breadcrumbs && (
        <nav className="flex mb-4" aria-label="Breadcrumb">
          <ol className="inline-flex items-center space-x-1 md:space-x-3">
            {breadcrumbs.map((crumb, index) => (
              <li key={index} className="inline-flex items-center">
                {index > 0 && (
                  <svg className="w-3 h-3 text-neutral-400 mx-1" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 6 10">
                    <path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="m1 9 4-4-4-4"/>
                  </svg>
                )}
                {crumb.href ? (
                  <a 
                    href={crumb.href} 
                    className="text-sm font-medium text-primary-500 hover:text-primary-700"
                  >
                    {crumb.label}
                  </a>
                ) : (
                  <span className="text-sm font-medium text-neutral-500">
                    {crumb.label}
                  </span>
                )}
              </li>
            ))}
          </ol>
        </nav>
      )}
      
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-h1 text-neutral-900 font-bold">{title}</h1>
          {subtitle && (
            <p className="mt-2 text-body text-neutral-500">{subtitle}</p>
          )}
        </div>
        {actions && (
          <div className="flex items-center space-x-4">
            {actions}
          </div>
        )}
      </div>
    </div>
  )
}

const LoadingSpinner: React.FC = () => {
  return (
    <div className="flex items-center justify-center min-h-screen">
      <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary-500"></div>
    </div>
  )
}

const EmptyState: React.FC<{
  title: string
  description: string
  action?: React.ReactNode
  icon?: React.ReactNode
}> = ({ title, description, action, icon }) => {
  return (
    <div className="text-center py-12">
      {icon && (
        <div className="mx-auto h-12 w-12 text-neutral-400 mb-4">
          {icon}
        </div>
      )}
      <h3 className="text-h3 text-neutral-900 mb-2">{title}</h3>
      <p className="text-body text-neutral-500 mb-6 max-w-md mx-auto">{description}</p>
      {action}
    </div>
  )
}

export { Card, StatusTag, PageHeader, LoadingSpinner, EmptyState }