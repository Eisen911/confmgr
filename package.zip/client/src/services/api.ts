import axios from 'axios'

// Create axios instance
const api = axios.create({
  baseURL: '/api',
  timeout: 10000,
  headers: {
    'Content-Type': 'application/json',
  },
})

// Request interceptor to add auth token
api.interceptors.request.use(
  (config) => {
    const token = localStorage.getItem('token')
    if (token) {
      config.headers.Authorization = `Bearer ${token}`
    }
    return config
  },
  (error) => {
    return Promise.reject(error)
  }
)

// Response interceptor to handle auth errors
api.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error.response?.status === 401) {
      localStorage.removeItem('token')
      window.location.href = '/login'
    }
    return Promise.reject(error)
  }
)

export default api

// Auth API
export const authAPI = {
  login: (credentials: { email: string; password: string }) =>
    api.post('/auth/login', credentials),
  
  register: (userData: {
    email: string
    password: string
    firstName: string
    lastName: string
    affiliation?: string
  }) => api.post('/auth/register', userData),
  
  getCurrentUser: () => api.get('/auth/me'),
  
  verifyEmail: (token: string) => api.post('/auth/verify-email', { token }),
  
  forgotPassword: (email: string) => api.post('/auth/forgot-password', { email }),
  
  resetPassword: (token: string, password: string) =>
    api.post('/auth/reset-password', { token, password }),
  
  changePassword: (currentPassword: string, newPassword: string) =>
    api.post('/auth/change-password', { currentPassword, newPassword }),
  
  updateProfile: (data: any) => api.put('/users/profile', data),
}

// Users API
export const usersAPI = {
  getProfile: () => api.get('/users/profile'),
  
  getUserConferences: () => api.get('/users/conferences'),
  
  getAllUsers: (params?: { page?: number; limit?: number; search?: string }) =>
    api.get('/users', { params }),
  
  getUserById: (id: string) => api.get(`/users/${id}`),
  
  updateUserRole: (id: string, role: string, conferenceId?: string) =>
    api.put(`/users/${id}/role`, { role, conferenceId }),
  
  removeUserRole: (id: string, role: string, conferenceId?: string) =>
    api.delete(`/users/${id}/role`, { data: { role, conferenceId } }),
}

// Conferences API
export const conferencesAPI = {
  getAllConferences: (params?: {
    status?: string
    page?: number
    limit?: number
    search?: string
  }) => api.get('/conferences', { params }),
  
  getConferenceById: (id: string, includeTracks?: boolean) =>
    api.get(`/conferences/${id}`, { params: { includeTracks } }),
  
  createConference: (data: any) => api.post('/conferences', data),
  
  updateConference: (id: string, data: any) => api.put(`/conferences/${id}`, data),
  
  deleteConference: (id: string) => api.delete(`/conferences/${id}`),
  
  getConferenceTracks: (id: string) => api.get(`/conferences/${id}/tracks`),
  
  createTrack: (id: string, data: any) => api.post(`/conferences/${id}/tracks`, data),
}

// Papers API
export const papersAPI = {
  getAllPapers: (params?: {
    conferenceId?: string
    status?: string
    trackId?: string
    page?: number
    limit?: number
    search?: string
  }) => api.get('/papers', { params }),
  
  getPaperById: (id: string) => api.get(`/papers/${id}`),
  
  submitPaper: (data: {
    title: string
    abstract: string
    keywords?: string[]
    conferenceId: string
    trackId?: string
    authors: Array<{
      authorId: string
      isCorrespondingAuthor?: boolean
      authorOrder: number
    }>
  }) => api.post('/papers', data),
  
  updatePaper: (id: string, data: any) => api.put(`/papers/${id}`, data),
  
  updatePaperStatus: (id: string, status: string, notes?: string) =>
    api.patch(`/papers/${id}/status`, { status, notes }),
  
  uploadPaperFile: (paperId: string, file: File, type: 'paper_file' | 'camera_ready_file') => {
    const formData = new FormData()
    formData.append('file', file)
    return api.post(`/uploads/papers/${paperId}?type=${type}`, formData, {
      headers: {
        'Content-Type': 'multipart/form-data',
      },
    })
  },
}

// Reviews API
export const reviewsAPI = {
  getReviewAssignments: (params?: {
    status?: string
    page?: number
    limit?: number
  }) => api.get('/reviews/assignments', { params }),
  
  getReviewAssignment: (id: string) => api.get(`/reviews/assignments/${id}`),
  
  submitReview: (assignmentId: string, data: {
    overallScore: number
    recommendation: 'accept' | 'minor_revision' | 'major_revision' | 'reject'
    confidenceLevel?: number
    strengthPoints?: string
    weaknessPoints?: string
    detailedComments?: string
    confidentialComments?: string
    criteriaScores: Array<{
      criteriaId: string
      score: number
      comments?: string
    }>
  }) => api.post(`/reviews/assignments/${assignmentId}/review`, data),
  
  getReviewCriteria: (conferenceId: string) => api.get(`/reviews/criteria/${conferenceId}`),
  
  assignReviewers: (data: {
    paperId: string
    reviewers: Array<{
      reviewerId: string
      dueDate: string
    }>
  }) => api.post('/reviews/assignments', data),
  
  removeReviewAssignment: (id: string) => api.delete(`/reviews/assignments/${id}`),
  
  getPaperReviews: (paperId: string) => api.get(`/reviews/papers/${paperId}/reviews`),
}

// Upload API
export const uploadAPI = {
  uploadProfileImage: (file: File) => {
    const formData = new FormData()
    formData.append('file', file)
    return api.post('/uploads/profile-image', formData, {
      headers: {
        'Content-Type': 'multipart/form-data',
      },
    })
  },
  
  downloadFile: (type: string, filename: string) =>
    api.get(`/uploads/download/${type}/${filename}`, {
      responseType: 'blob',
    }),
  
  deleteFile: (type: string, filename: string) =>
    api.delete(`/uploads/${type}/${filename}`),
  
  getFileInfo: (type: string, filename: string) =>
    api.get(`/uploads/info/${type}/${filename}`),
}