import React from 'react'
import { useAuth } from '../../contexts/AuthContext'
import { PageHeader, Card, StatusTag } from '../../components/ui'
import { FileText, MessageSquare, Building2, Users } from 'lucide-react'
import { useQuery } from 'react-query'
import { conferencesAPI, papersAPI, reviewsAPI } from '../../services/api'
import { formatDate, formatRelativeTime } from '../../lib/utils'

const DashboardPage: React.FC = () => {
  const { user } = useAuth()

  // Fetch user's conferences
  const { data: conferencesData } = useQuery(
    'user-conferences',
    () => user && user.roles.includes('author') ? conferencesAPI.getAllConferences() : { data: { conferences: [] } }
  )

  // Fetch user's papers
  const { data: papersData } = useQuery(
    'user-papers',
    () => user && user.roles.includes('author') ? papersAPI.getAllPapers() : { data: { papers: [] } }
  )

  // Fetch review assignments
  const { data: reviewsData } = useQuery(
    'user-reviews',
    () => user && user.roles.includes('reviewer') ? reviewsAPI.getReviewAssignments() : { data: { assignments: [] } }
  )

  const conferences = conferencesData?.data?.conferences || []
  const papers = papersData?.data?.papers || []
  const assignments = reviewsData?.data?.assignments || []

  const stats = {
    conferences: conferences.length,
    papers: papers.length,
    reviews: assignments.length,
    pendingReviews: assignments.filter((a: any) => !a.completed_date).length
  }

  const quickActions = [
    {
      title: 'Browse Conferences',
      description: 'Find conferences to submit to or attend',
      href: '/conferences',
      icon: Building2,
      roles: ['author', 'reviewer', 'attendee', 'admin']
    },
    {
      title: 'Submit Paper',
      description: 'Submit a new paper to a conference',
      href: '/papers/submit',
      icon: FileText,
      roles: ['author']
    },
    {
      title: 'My Reviews',
      description: 'View and complete your review assignments',
      href: '/reviews',
      icon: MessageSquare,
      roles: ['reviewer']
    }
  ]

  const filteredActions = quickActions.filter(action => 
    user?.roles?.some(role => action.roles.includes(role))
  )

  return (
    <>
      <PageHeader 
        title={`Welcome back, ${user?.firstName}!`}
        subtitle="Here's what's happening with your conference activities"
      />
      
      <div className="space-y-8">
        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          <Card>
            <div className="flex items-center">
              <div className="flex-shrink-0">
                <Building2 className="h-8 w-8 text-primary-500" />
              </div>
              <div className="ml-4">
                <p className="text-sm font-medium text-neutral-500">Conferences</p>
                <p className="text-2xl font-semibold text-neutral-900">{stats.conferences}</p>
              </div>
            </div>
          </Card>
          
          <Card>
            <div className="flex items-center">
              <div className="flex-shrink-0">
                <FileText className="h-8 w-8 text-primary-500" />
              </div>
              <div className="ml-4">
                <p className="text-sm font-medium text-neutral-500">Papers</p>
                <p className="text-2xl font-semibold text-neutral-900">{stats.papers}</p>
              </div>
            </div>
          </Card>
          
          {user?.roles?.includes('reviewer') && (
            <>
              <Card>
                <div className="flex items-center">
                  <div className="flex-shrink-0">
                    <MessageSquare className="h-8 w-8 text-primary-500" />
                  </div>
                  <div className="ml-4">
                    <p className="text-sm font-medium text-neutral-500">Total Reviews</p>
                    <p className="text-2xl font-semibold text-neutral-900">{stats.reviews}</p>
                  </div>
                </div>
              </Card>
              
              <Card>
                <div className="flex items-center">
                  <div className="flex-shrink-0">
                    <Users className="h-8 w-8 text-warning-500" />
                  </div>
                  <div className="ml-4">
                    <p className="text-sm font-medium text-neutral-500">Pending Reviews</p>
                    <p className="text-2xl font-semibold text-warning-600">{stats.pendingReviews}</p>
                  </div>
                </div>
              </Card>
            </>
          )}
        </div>

        {/* Quick Actions */}
        <div>
          <h2 className="text-h2 text-neutral-900 mb-4">Quick Actions</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {filteredActions.map((action) => (
              <a
                key={action.title}
                href={action.href}
                className="group relative block p-6 bg-white rounded-card shadow-md hover:shadow-lg transition-all duration-250"
              >
                <div>
                  <span className="rounded-lg inline-flex p-3 bg-primary-50 text-primary-600 ring-4 ring-white group-hover:bg-primary-100 transition-colors">
                    <action.icon className="h-6 w-6" />
                  </span>
                </div>
                <div className="mt-4">
                  <h3 className="text-lg font-medium text-neutral-900 group-hover:text-primary-600">
                    <span className="absolute inset-0" />
                    {action.title}
                  </h3>
                  <p className="mt-2 text-sm text-neutral-500">
                    {action.description}
                  </p>
                </div>
              </a>
            ))}
          </div>
        </div>

        {/* Recent Activity */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Recent Papers */}
          {papers.length > 0 && (
            <Card>
              <h3 className="text-h3 text-neutral-900 mb-4">Recent Papers</h3>
              <div className="space-y-4">
                {papers.slice(0, 3).map((paper: any) => (
                  <div key={paper.id} className="flex items-center justify-between py-3 border-b border-neutral-100 last:border-b-0">
                    <div className="flex-1">
                      <h4 className="text-sm font-medium text-neutral-900">{paper.title}</h4>
                      <p className="text-sm text-neutral-500">{paper.conference_name}</p>
                    </div>
                    <div className="ml-4">
                      <StatusTag status={paper.status} />
                      <p className="text-xs text-neutral-500 mt-1">
                        {formatRelativeTime(paper.submission_date)}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
              <div className="mt-4">
                <a href="/papers" className="text-sm text-primary-600 hover:text-primary-500 font-medium">
                  View all papers →
                </a>
              </div>
            </Card>
          )}

          {/* Recent Review Assignments */}
          {assignments.length > 0 && (
            <Card>
              <h3 className="text-h3 text-neutral-900 mb-4">Review Assignments</h3>
              <div className="space-y-4">
                {assignments.slice(0, 3).map((assignment: any) => (
                  <div key={assignment.assignment_id} className="flex items-center justify-between py-3 border-b border-neutral-100 last:border-b-0">
                    <div className="flex-1">
                      <h4 className="text-sm font-medium text-neutral-900">{assignment.title}</h4>
                      <p className="text-sm text-neutral-500">{assignment.conference_name}</p>
                    </div>
                    <div className="ml-4 text-right">
                      {assignment.completed_date ? (
                        <StatusTag status="completed" />
                      ) : assignment.due_date < new Date().toISOString() ? (
                        <StatusTag status="overdue" />
                      ) : (
                        <StatusTag status="pending" />
                      )}
                      <p className="text-xs text-neutral-500 mt-1">
                        Due {formatDate(assignment.due_date)}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
              <div className="mt-4">
                <a href="/reviews" className="text-sm text-primary-600 hover:text-primary-500 font-medium">
                  View all reviews →
                </a>
              </div>
            </Card>
          )}
        </div>
      </div>
    </>
  )
}

export default DashboardPage