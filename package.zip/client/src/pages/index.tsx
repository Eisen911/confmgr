import React from 'react'
import { PageHeader } from '../../components/ui'
import { Card } from '../../components/ui'
import { FileText } from 'lucide-react'

const CreateConferencePage: React.FC = () => {
  return (
    <>
      <PageHeader 
        title="Create New Conference"
        subtitle="Set up a new academic conference"
      />
      
      <div className="space-y-6">
        <Card>
          <h2 className="text-h2 text-neutral-900 mb-4">Conference Creation Form</h2>
          <p className="text-neutral-600">
            This page will contain a comprehensive form for creating new conferences with all necessary details.
          </p>
        </Card>
      </div>
    </>
  )
}

export default CreateConferencePage

const ForgotPasswordPage: React.FC = () => {
  return (
    <div className="min-h-screen flex items-center justify-center bg-neutral-50 py-12 px-4 sm:px-6 lg:px-8">
      <Card>
        <h2 className="text-h2 text-neutral-900 mb-4">Forgot Password</h2>
        <p className="text-neutral-600">Password reset functionality will be implemented here.</p>
      </Card>
    </div>
  )
}

const ResetPasswordPage: React.FC = () => {
  return (
    <div className="min-h-screen flex items-center justify-center bg-neutral-50 py-12 px-4 sm:px-6 lg:px-8">
      <Card>
        <h2 className="text-h2 text-neutral-900 mb-4">Reset Password</h2>
        <p className="text-neutral-600">Password reset form will be implemented here.</p>
      </Card>
    </div>
  )
}

const ProfilePage: React.FC = () => {
  return (
    <>
      <PageHeader title="Profile Settings" subtitle="Manage your account information" />
      <Card>
        <h2 className="text-h2 text-neutral-900 mb-4">User Profile</h2>
        <p className="text-neutral-600">Profile management functionality will be implemented here.</p>
      </Card>
    </>
  )
}

const PapersPage: React.FC = () => {
  return (
    <>
      <PageHeader 
        title="My Papers" 
        subtitle="Manage your paper submissions"
        actions={
          <a href="/papers/submit" className="btn-primary">
            Submit New Paper
          </a>
        }
      />
      <Card>
        <div className="text-center py-12">
          <FileText className="mx-auto h-12 w-12 text-neutral-400 mb-4" />
          <h3 className="text-lg font-medium text-neutral-900 mb-2">No papers yet</h3>
          <p className="text-neutral-500 mb-6">Submit your first paper to get started.</p>
          <a href="/papers/submit" className="btn-primary">
            Submit Paper
          </a>
        </div>
      </Card>
    </>
  )
}

const SubmitPaperPage: React.FC = () => {
  return (
    <>
      <PageHeader title="Submit Paper" subtitle="Submit a new paper to a conference" />
      <Card>
        <h2 className="text-h2 text-neutral-900 mb-4">Paper Submission Form</h2>
        <p className="text-neutral-600">Paper submission form with file upload will be implemented here.</p>
      </Card>
    </>
  )
}

const PaperDetailPage: React.FC = () => {
  return (
    <>
      <PageHeader title="Paper Details" subtitle="View and manage your paper submission" />
      <Card>
        <h2 className="text-h2 text-neutral-900 mb-4">Paper Management</h2>
        <p className="text-neutral-600">Paper detail view with review status will be implemented here.</p>
      </Card>
    </>
  )
}

const ReviewsPage: React.FC = () => {
  return (
    <>
      <PageHeader title="Review Assignments" subtitle="Complete your assigned paper reviews" />
      <Card>
        <div className="text-center py-12">
          <FileText className="mx-auto h-12 w-12 text-neutral-400 mb-4" />
          <h3 className="text-lg font-medium text-neutral-900 mb-2">No review assignments</h3>
          <p className="text-neutral-500">You don't have any review assignments at the moment.</p>
        </div>
      </Card>
    </>
  )
}

const ReviewDetailPage: React.FC = () => {
  return (
    <>
      <PageHeader title="Review Assignment" subtitle="Complete the review for this paper" />
      <Card>
        <h2 className="text-h2 text-neutral-900 mb-4">Paper Review</h2>
        <p className="text-neutral-600">Review form with criteria and scoring will be implemented here.</p>
      </Card>
    </>
  )
}

const AdminPage: React.FC = () => {
  return (
    <>
      <PageHeader title="Admin Dashboard" subtitle="Manage the conference management system" />
      <div className="space-y-6">
        <Card>
          <h2 className="text-h2 text-neutral-900 mb-4">System Administration</h2>
          <p className="text-neutral-600">Administrative functions and system management will be implemented here.</p>
        </Card>
      </div>
    </>
  )
}

const UsersPage: React.FC = () => {
  return (
    <>
      <PageHeader title="User Management" subtitle="Manage system users and roles" />
      <Card>
        <h2 className="text-h2 text-neutral-900 mb-4">User Management</h2>
        <p className="text-neutral-600">User management interface will be implemented here.</p>
      </Card>
    </>
  )
}

export {
  ForgotPasswordPage,
  ResetPasswordPage,
  ProfilePage,
  PapersPage,
  SubmitPaperPage,
  PaperDetailPage,
  ReviewsPage,
  ReviewDetailPage,
  AdminPage,
  UsersPage
}