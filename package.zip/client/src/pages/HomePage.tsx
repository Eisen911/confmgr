import React from 'react'
import { Link } from 'react-router-dom'
import { Building2, Users, FileText, MessageSquare } from 'lucide-react'
import { Card, EmptyState } from '../components/ui'

const HomePage: React.FC = () => {
  const features = [
    {
      icon: Building2,
      title: 'Conference Management',
      description: 'Create and manage academic conferences with ease. Set submission deadlines, organize tracks, and handle registrations.'
    },
    {
      icon: FileText,
      title: 'Paper Submissions',
      description: 'Streamlined submission process for authors with file upload, review status tracking, and automated notifications.'
    },
    {
      icon: MessageSquare,
      title: 'Review System',
      description: 'Comprehensive peer review system with blind review capabilities, review criteria, and reviewer assignment.'
    },
    {
      icon: Users,
      title: 'User Management',
      description: 'Role-based access control for authors, reviewers, attendees, and administrators with comprehensive user profiles.'
    }
  ]

  return (
    <div className="min-h-screen bg-neutral-50">
      {/* Header */}
      <header className="bg-white shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center py-6">
            <div className="flex items-center">
              <h1 className="text-2xl font-bold text-neutral-900">Conference Management System</h1>
            </div>
            <div className="flex items-center space-x-4">
              <Link
                to="/login"
                className="text-neutral-700 hover:text-primary-600 font-medium"
              >
                Sign in
              </Link>
              <Link
                to="/register"
                className="btn-primary"
              >
                Get Started
              </Link>
            </div>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h1 className="text-display text-neutral-900 mb-6">
              Manage Your Conferences with Confidence
            </h1>
            <p className="text-h2 text-neutral-600 mb-8 max-w-3xl mx-auto">
              A comprehensive full-stack platform for academic conference management, 
              paper submissions, and peer review processes.
            </p>
            <div className="flex items-center justify-center space-x-4">
              <Link
                to="/register"
                className="btn-primary text-lg px-8 py-4"
              >
                Start Free Trial
              </Link>
              <Link
                to="/login"
                className="btn-secondary text-lg px-8 py-4"
              >
                Sign In
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 bg-neutral-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-h1 text-neutral-900 mb-4">
              Everything You Need for Conference Management
            </h2>
            <p className="text-h3 text-neutral-600 max-w-3xl mx-auto">
              Our platform provides all the tools necessary to organize, manage, 
              and run successful academic conferences from start to finish.
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {features.map((feature, index) => (
              <Card key={index} className="text-center">
                <div className="mx-auto h-12 w-12 bg-primary-100 rounded-lg flex items-center justify-center mb-4">
                  <feature.icon className="h-6 w-6 text-primary-600" />
                </div>
                <h3 className="text-h3 text-neutral-900 mb-2">{feature.title}</h3>
                <p className="text-body text-neutral-600">{feature.description}</p>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-primary-500">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-h1 text-white mb-4">
            Ready to Transform Your Conference Management?
          </h2>
          <p className="text-h3 text-primary-100 mb-8 max-w-2xl mx-auto">
            Join thousands of researchers and conference organizers who trust our platform 
            to manage their academic events.
          </p>
          <div className="flex items-center justify-center space-x-4">
            <Link
              to="/register"
              className="bg-white text-primary-600 hover:bg-neutral-50 px-8 py-4 rounded-button font-body font-medium text-lg transition-colors"
            >
              Get Started Today
            </Link>
            <Link
              to="/login"
              className="border-2 border-white text-white hover:bg-white hover:text-primary-600 px-8 py-4 rounded-button font-body font-medium text-lg transition-colors"
            >
              Sign In
            </Link>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-neutral-900 py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h3 className="text-h2 text-white mb-4">Conference Management System</h3>
            <p className="text-body text-neutral-400 mb-8">
              Empowering academic conferences worldwide with modern technology and seamless user experience.
            </p>
            <div className="border-t border-neutral-800 pt-8">
              <p className="text-body-sm text-neutral-500">
                © 2025 Conference Management System. Built by MiniMax Agent.
              </p>
            </div>
          </div>
        </div>
      </footer>
    </div>
  )
}

export default HomePage