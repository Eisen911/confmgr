import React from 'react'
import { useParams, Navigate } from 'react-router-dom'
import { PageHeader } from '../../components/ui'

const ConferenceDetailPage: React.FC = () => {
  const { id } = useParams()

  if (!id) {
    return <Navigate to="/conferences" />
  }

  return (
    <>
      <PageHeader 
        title="Conference Details"
        subtitle={`Conference ID: ${id}`}
      />
      
      <div className="space-y-6">
        <div className="bg-white rounded-card p-8 shadow-md">
          <h2 className="text-h2 text-neutral-900 mb-4">Conference Management</h2>
          <p className="text-neutral-600">
            This page will display detailed conference information, tracks, and management options.
          </p>
        </div>
      </div>
    </>
  )
}

export default ConferenceDetailPage