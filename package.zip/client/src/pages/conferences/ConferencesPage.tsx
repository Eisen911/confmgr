import React from 'react'
import { PageHeader } from '../../components/ui'
import { useQuery } from 'react-query'
import { conferencesAPI } from '../../services/api'
import { Building2, Calendar, MapPin, Users } from 'lucide-react'
import { Card, StatusTag } from '../../components/ui'
import { formatDate } from '../../lib/utils'

const ConferencesPage: React.FC = () => {
  const { data, isLoading } = useQuery(
    'conferences',
    () => conferencesAPI.getAllConferences({ limit: 20 })
  )

  const conferences = data?.data?.conferences || []

  return (
    <>
      <PageHeader 
        title="Conferences"
        subtitle="Browse and explore academic conferences"
        actions={
          <a href="/conferences/create" className="btn-primary">
            Create Conference
          </a>
        }
      />
      
      <div className="space-y-6">
        {isLoading ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {[...Array(6)].map((_, i) => (
              <Card key={i} className="animate-pulse">
                <div className="h-4 bg-neutral-200 rounded w-3/4 mb-2"></div>
                <div className="h-3 bg-neutral-200 rounded w-full mb-4"></div>
                <div className="h-3 bg-neutral-200 rounded w-2/3"></div>
              </Card>
            ))}
          </div>
        ) : conferences.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {conferences.map((conference: any) => (
              <Card key={conference.id} hover className="cursor-pointer">
                <div className="flex items-start justify-between mb-4">
                  <h3 className="text-h3 text-neutral-900">{conference.name}</h3>
                  <StatusTag status={conference.status} />
                </div>
                
                <p className="text-sm text-neutral-600 mb-4 line-clamp-3">
                  {conference.description}
                </p>
                
                <div className="space-y-2 text-sm text-neutral-500">
                  <div className="flex items-center">
                    <Calendar className="h-4 w-4 mr-2" />
                    <span>{formatDate(conference.start_date)} - {formatDate(conference.end_date)}</span>
                  </div>
                  <div className="flex items-center">
                    <Users className="h-4 w-4 mr-2" />
                    <span>{conference.paper_count || 0} papers submitted</span>
                  </div>
                </div>
                
                <div className="mt-4 pt-4 border-t border-neutral-100">
                  <a 
                    href={`/conferences/${conference.id}`}
                    className="text-sm text-primary-600 hover:text-primary-500 font-medium"
                  >
                    View Details →
                  </a>
                </div>
              </Card>
            ))}
          </div>
        ) : (
          <Card>
            <div className="text-center py-12">
              <Building2 className="mx-auto h-12 w-12 text-neutral-400 mb-4" />
              <h3 className="text-lg font-medium text-neutral-900 mb-2">No conferences found</h3>
              <p className="text-neutral-500 mb-6">Get started by creating your first conference.</p>
              <a href="/conferences/create" className="btn-primary">
                Create Conference
              </a>
            </div>
          </Card>
        )}
      </div>
    </>
  )
}

export default ConferencesPage