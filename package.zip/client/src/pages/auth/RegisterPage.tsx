import React, { useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { useForm } from 'react-hook-form'
import { zodResolver } from '@hookform/resolvers/zod'
import { z } from 'zod'
import { useAuth } from '../../contexts/AuthContext'
import { useNotification } from '../../contexts/NotificationContext'
import { Card, Input } from '../../components/ui'
import { Button } from '../../components/ui/Button'
import { isValidEmail, isValidPassword } from '../../lib/utils'

const registerSchema = z.object({
  firstName: z.string().min(2, 'First name must be at least 2 characters'),
  lastName: z.string().min(2, 'Last name must be at least 2 characters'),
  email: z.string().refine(isValidEmail, 'Please enter a valid email address'),
  password: z.string().refine(isValidPassword, 'Password must be at least 8 characters with uppercase, lowercase, number, and special character'),
  affiliation: z.string().optional()
})

type RegisterFormData = z.infer<typeof registerSchema>

const RegisterPage: React.FC = () => {
  const [isLoading, setIsLoading] = useState(false)
  const { register: registerUser } = useAuth()
  const { showNotification } = useNotification()
  const navigate = useNavigate()
  
  const {
    register,
    handleSubmit,
    formState: { errors }
  } = useForm<RegisterFormData>({
    resolver: zodResolver(registerSchema)
  })

  const onSubmit = async (data: RegisterFormData) => {
    setIsLoading(true)
    try {
      await registerUser(data)
      showNotification('success', 'Account created successfully! Please check your email to verify your account.')
      navigate('/login')
    } catch (error: any) {
      const message = error.response?.data?.error || 'Registration failed. Please try again.'
      showNotification('error', message)
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-neutral-50 py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-md w-full space-y-8">
        <div>
          <h1 className="text-center text-3xl font-bold text-neutral-900">
            Conference Management System
          </h1>
          <h2 className="mt-6 text-center text-h2 text-neutral-600">
            Create your account
          </h2>
        </div>
        
        <Card>
          <form className="space-y-6" onSubmit={handleSubmit(onSubmit)}>
            <div className="grid grid-cols-2 gap-4">
              <Input
                {...register('firstName')}
                type="text"
                label="First Name"
                error={errors.firstName?.message}
                required
              />
              
              <Input
                {...register('lastName')}
                type="text"
                label="Last Name"
                error={errors.lastName?.message}
                required
              />
            </div>

            <Input
              {...register('email')}
              type="email"
              label="Email address"
              error={errors.email?.message}
              required
            />

            <Input
              {...register('affiliation')}
              type="text"
              label="Affiliation (Optional)"
              error={errors.affiliation?.message}
            />

            <Input
              {...register('password')}
              type="password"
              label="Password"
              error={errors.password?.message}
              helperText="Must be at least 8 characters with uppercase, lowercase, number, and special character"
              required
            />

            <Button
              type="submit"
              className="w-full"
              isLoading={isLoading}
            >
              Create account
            </Button>
          </form>

          <div className="mt-6">
            <div className="relative">
              <div className="absolute inset-0 flex items-center">
                <div className="w-full border-t border-neutral-200" />
              </div>
              <div className="relative flex justify-center text-sm">
                <span className="px-2 bg-white text-neutral-500">
                  Already have an account?
                </span>
              </div>
            </div>

            <div className="mt-6">
              <Link
                to="/login"
                className="w-full flex justify-center py-3 px-4 border border-transparent rounded-button text-sm font-medium text-primary-600 bg-white hover:bg-neutral-50 border-neutral-200 transition-colors"
              >
                Sign in
              </Link>
            </div>
          </div>
        </Card>
      </div>
    </div>
  )
}

export default RegisterPage