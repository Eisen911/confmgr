import React from 'react'
import { Routes, Route, Navigate } from 'react-router-dom'
import { useAuth } from './contexts/AuthContext'
import Layout from './components/Layout'
import LoadingSpinner from './components/LoadingSpinner'

// Pages
import HomePage from './pages/HomePage'
import LoginPage from './pages/auth/LoginPage'
import RegisterPage from './pages/auth/RegisterPage'
import ForgotPasswordPage from './pages/auth/ForgotPasswordPage'
import ResetPasswordPage from './pages/auth/ResetPasswordPage'
import DashboardPage from './pages/dashboard/DashboardPage'
import ProfilePage from './pages/profile/ProfilePage'
import ConferencesPage from './pages/conferences/ConferencesPage'
import CreateConferencePage from './pages/conferences/CreateConferencePage'
import ConferenceDetailPage from './pages/conferences/ConferenceDetailPage'
import PapersPage from './pages/papers/PapersPage'
import SubmitPaperPage from './pages/papers/SubmitPaperPage'
import PaperDetailPage from './pages/papers/PaperDetailPage'
import ReviewsPage from './pages/reviews/ReviewsPage'
import ReviewDetailPage from './pages/reviews/ReviewDetailPage'
import AdminPage from './pages/admin/AdminPage'
import UsersPage from './pages/admin/UsersPage'

// Protected Route component
interface ProtectedRouteProps {
  children: React.ReactNode
  requiredRole?: string[]
  requireAuth?: boolean
}

const ProtectedRoute: React.FC<ProtectedRouteProps> = ({ 
  children, 
  requiredRole, 
  requireAuth = true 
}) => {
  const { isAuthenticated, user, isLoading } = useAuth()

  if (isLoading) {
    return <LoadingSpinner />
  }

  if (requireAuth && !isAuthenticated) {
    return <Navigate to="/login" replace />
  }

  if (requiredRole && user) {
    const hasRequiredRole = requiredRole.some(role => user.roles.includes(role))
    if (!hasRequiredRole) {
      return <Navigate to="/dashboard" replace />
    }
  }

  return <>{children}</>
}

// Public Route component (redirect if authenticated)
const PublicRoute: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { isAuthenticated, isLoading } = useAuth()

  if (isLoading) {
    return <LoadingSpinner />
  }

  if (isAuthenticated) {
    return <Navigate to="/dashboard" replace />
  }

  return <>{children}</>
}

function App() {
  return (
    <div className="min-h-screen bg-neutral-50">
      <Routes>
        {/* Public routes */}
        <Route 
          path="/" 
          element={
            <PublicRoute>
              <HomePage />
            </PublicRoute>
          } 
        />
        <Route 
          path="/login" 
          element={
            <PublicRoute>
              <LoginPage />
            </PublicRoute>
          } 
        />
        <Route 
          path="/register" 
          element={
            <PublicRoute>
              <RegisterPage />
            </PublicRoute>
          } 
        />
        <Route 
          path="/forgot-password" 
          element={
            <PublicRoute>
              <ForgotPasswordPage />
            </PublicRoute>
          } 
        />
        <Route 
          path="/reset-password" 
          element={
            <PublicRoute>
              <ResetPasswordPage />
            </PublicRoute>
          } 
        />

        {/* Protected routes */}
        <Route 
          path="/dashboard" 
          element={
            <ProtectedRoute>
              <Layout>
                <DashboardPage />
              </Layout>
            </ProtectedRoute>
          } 
        />
        <Route 
          path="/profile" 
          element={
            <ProtectedRoute>
              <Layout>
                <ProfilePage />
              </Layout>
            </ProtectedRoute>
          } 
        />

        {/* Conference routes */}
        <Route 
          path="/conferences" 
          element={
            <ProtectedRoute>
              <Layout>
                <ConferencesPage />
              </Layout>
            </ProtectedRoute>
          } 
        />
        <Route 
          path="/conferences/create" 
          element={
            <ProtectedRoute requiredRole={['admin']}>
              <Layout>
                <CreateConferencePage />
              </Layout>
            </ProtectedRoute>
          } 
        />
        <Route 
          path="/conferences/:id" 
          element={
            <ProtectedRoute>
              <Layout>
                <ConferenceDetailPage />
              </Layout>
            </ProtectedRoute>
          } 
        />

        {/* Paper routes */}
        <Route 
          path="/papers" 
          element={
            <ProtectedRoute>
              <Layout>
                <PapersPage />
              </Layout>
            </ProtectedRoute>
          } 
        />
        <Route 
          path="/papers/submit" 
          element={
            <ProtectedRoute requiredRole={['author']}>
              <Layout>
                <SubmitPaperPage />
              </Layout>
            </ProtectedRoute>
          } 
        />
        <Route 
          path="/papers/:id" 
          element={
            <ProtectedRoute>
              <Layout>
                <PaperDetailPage />
              </Layout>
            </ProtectedRoute>
          } 
        />

        {/* Review routes */}
        <Route 
          path="/reviews" 
          element={
            <ProtectedRoute requiredRole={['reviewer']}>
              <Layout>
                <ReviewsPage />
              </Layout>
            </ProtectedRoute>
          } 
        />
        <Route 
          path="/reviews/:id" 
          element={
            <ProtectedRoute requiredRole={['reviewer']}>
              <Layout>
                <ReviewDetailPage />
              </Layout>
            </ProtectedRoute>
          } 
        />

        {/* Admin routes */}
        <Route 
          path="/admin" 
          element={
            <ProtectedRoute requiredRole={['admin']}>
              <Layout>
                <AdminPage />
              </Layout>
            </ProtectedRoute>
          } 
        />
        <Route 
          path="/admin/users" 
          element={
            <ProtectedRoute requiredRole={['admin']}>
              <Layout>
                <UsersPage />
              </Layout>
            </ProtectedRoute>
          } 
        />

        {/* 404 page */}
        <Route 
          path="*" 
          element={
            <div className="min-h-screen flex items-center justify-center">
              <div className="text-center">
                <h1 className="text-h1 text-neutral-900 mb-4">404 - Page Not Found</h1>
                <p className="text-body text-neutral-500 mb-8">The page you're looking for doesn't exist.</p>
                <a 
                  href="/" 
                  className="btn-primary inline-block"
                >
                  Go Home
                </a>
              </div>
            </div>
          } 
        />
      </Routes>
    </div>
  )
}

export default App