# Conference Management System

A comprehensive full-stack web application for managing academic conferences, paper submissions, and peer review processes. Built with modern technologies and designed for scalability and user experience.

## 🚀 Features

### Core Functionality
- **User Management System** - Role-based authentication with JWT
- **Conference Management** - Create, configure, and manage academic conferences
- **Paper Submission System** - Complete submission workflow with file uploads
- **Review System** - Comprehensive peer review with blind review capabilities
- **Administrative Dashboard** - System administration and analytics
- **Email Notifications** - Automated email system for all important events

### User Roles
- **Admin** - Full system access, user management, conference creation
- **Author** - Submit papers, manage submissions, track status
- **Reviewer** - Complete assigned reviews, manage review assignments
- **Attendee** - Register for conferences, view accepted papers

### Technical Features
- **Responsive Design** - Works seamlessly on desktop, tablet, and mobile
- **Real-time Updates** - Live status updates for submissions and reviews
- **File Management** - Secure file upload and storage system
- **Email Integration** - Gmail-based email service for notifications
- **Database Security** - PostgreSQL with proper indexing and constraints
- **API Documentation** - RESTful API with comprehensive endpoints

## 🛠 Technology Stack

### Backend
- **Node.js** with **TypeScript** for robust server-side development
- **Express.js** framework for API development
- **PostgreSQL** database with advanced schema design
- **JWT** authentication with role-based access control
- **Nodemailer** for email notifications
- **Multer** for file upload handling
- **bcryptjs** for password hashing
- **Helmet** for security headers

### Frontend
- **React 18** with **TypeScript** for modern UI development
- **Vite** for fast development and building
- **React Router** for client-side routing
- **React Query** for server state management
- **React Hook Form** with **Zod** validation
- **Tailwind CSS** for responsive styling
- **Lucide React** for consistent iconography

### Development Tools
- **TypeScript** for type safety across the entire stack
- **ESLint** and **Prettier** for code quality
- **Concurrently** for running multiple development processes
- **Nodemon** for automatic server restarts

## 📁 Project Structure

```
conference-management-system/
├── src/
│   ├── server/                 # Backend server code
│   │   ├── routes/            # API route handlers
│   │   ├── middleware/        # Authentication & authorization
│   │   ├── services/          # Business logic services
│   │   └── database/          # Database connection & queries
│   └── client/                # Frontend React application
│       ├── src/
│       │   ├── components/    # Reusable UI components
│       │   ├── pages/         # Application pages
│       │   ├── contexts/      # React context providers
│       │   ├── services/      # API service layer
│       │   └── lib/           # Utility functions
├── database/                  # Database schema and migrations
├── uploads/                   # File storage directory
└── package.json              # Root package configuration
```

## 🚀 Quick Start

### Prerequisites
- **Node.js** 18+ and **npm**
- **PostgreSQL** 12+
- **Gmail Account** for email notifications (optional but recommended)

### Installation

1. **Clone the repository**
   ```bash
   git clone <repository-url>
   cd conference-management-system
   ```

2. **Install dependencies**
   ```bash
   # Install root dependencies
   npm install
   
   # Install client dependencies
   cd client
   npm install
   cd ..
   ```

3. **Database Setup**
   ```bash
   # Create PostgreSQL database
   createdb conference_management
   
   # Run database schema
   psql conference_management < database/schema.sql
   ```

4. **Environment Configuration**
   ```bash
   # Copy environment template
   cp .env.example .env
   
   # Edit .env with your configuration
   nano .env
   ```

5. **Start the application**
   ```bash
   # Development mode (runs both client and server)
   npm run dev
   
   # Or run separately:
   # Server: npm run server:dev
   # Client: npm run client:dev
   ```

6. **Access the application**
   - Frontend: http://localhost:3000
   - Backend API: http://localhost:5000

## ⚙️ Configuration

### Environment Variables

Create a `.env` file in the root directory with the following variables:

```env
# Database Configuration
DB_HOST=localhost
DB_PORT=5432
DB_NAME=conference_management
DB_USER=postgres
DB_PASSWORD=your_database_password

# JWT Configuration
JWT_SECRET=your-super-secret-jwt-key-change-in-production-2025

# Email Configuration
EMAIL_USER=your-email@gmail.com
EMAIL_PASSWORD=your-app-password

# Application Configuration
PORT=5000
NODE_ENV=development
CLIENT_URL=http://localhost:3000

# File Upload Configuration
MAX_FILE_SIZE_MB=50
ALLOWED_FILE_TYPES=pdf,docx,doc
```

### Email Setup (Gmail)

1. **Enable 2-Factor Authentication** on your Gmail account
2. **Generate an App Password**:
   - Go to Google Account settings
   - Security → 2-Step Verification → App passwords
   - Select "Mail" and "Other (Custom name)"
   - Use the generated password in `EMAIL_PASSWORD`

### Database Configuration

The system uses PostgreSQL with the following main tables:
- `users` - User accounts and profiles
- `conferences` - Conference information
- `papers` - Paper submissions
- `review_assignments` - Review assignments
- `reviews` - Completed reviews
- `conference_registrations` - Conference registrations

## 📚 API Documentation

### Authentication Endpoints
- `POST /api/auth/register` - User registration
- `POST /api/auth/login` - User login
- `GET /api/auth/me` - Get current user
- `POST /api/auth/forgot-password` - Request password reset
- `POST /api/auth/reset-password` - Reset password

### Conference Endpoints
- `GET /api/conferences` - List conferences
- `POST /api/conferences` - Create conference (Admin)
- `GET /api/conferences/:id` - Get conference details
- `PUT /api/conferences/:id` - Update conference (Admin)

### Paper Endpoints
- `GET /api/papers` - List papers (with role-based filtering)
- `POST /api/papers` - Submit new paper
- `GET /api/papers/:id` - Get paper details
- `PUT /api/papers/:id` - Update paper (Author only)

### Review Endpoints
- `GET /api/reviews/assignments` - Get review assignments
- `POST /api/reviews/assignments/:id/review` - Submit review
- `POST /api/reviews/assignments` - Assign reviewers (Admin)

## 🎨 Frontend Components

### Layout Components
- **Layout** - Main application layout with navigation
- **PageHeader** - Standardized page headers with breadcrumbs
- **Card** - Reusable content containers
- **StatusTag** - Status indicators for papers and reviews

### Form Components
- **Input** - Form input with validation
- **Button** - Consistent button styling with loading states
- **StatusTag** - Color-coded status indicators

### Page Components
- **Dashboard** - User overview and quick actions
- **Conferences** - Browse and manage conferences
- **Papers** - Submit and track paper submissions
- **Reviews** - Complete review assignments
- **Admin** - System administration interface

## 🔒 Security Features

### Authentication & Authorization
- **JWT-based authentication** with secure token storage
- **Role-based access control** (RBAC) throughout the system
- **Password hashing** with bcryptjs for security
- **Session management** with configurable timeouts

### File Security
- **File type validation** with configurable allowed types
- **File size limits** with configurable maximum sizes
- **Secure file storage** with proper access controls
- **Path traversal protection** for uploaded files

### API Security
- **Input validation** with Zod schema validation
- **SQL injection protection** with parameterized queries
- **CORS configuration** for cross-origin requests
- **Rate limiting** (recommended for production)

## 🧪 Testing

### Manual Testing Checklist

1. **User Registration & Authentication**
   - [ ] Register new user
   - [ ] Email verification workflow
   - [ ] Login with valid credentials
   - [ ] Password reset functionality
   - [ ] Invalid credential handling

2. **Conference Management**
   - [ ] Create conference (Admin)
   - [ ] View conference list
   - [ ] Conference details page
   - [ ] Update conference settings
   - [ ] Track management

3. **Paper Submission**
   - [ ] Submit paper with all fields
   - [ ] File upload functionality
   - [ ] Paper status updates
   - [ ] Author dashboard
   - [ ] Paper detail view

4. **Review System**
   - [ ] Assign reviewers (Admin)
   - [ ] Reviewer dashboard
   - [ ] Complete review form
   - [ ] Review submission
   - [ ] Review results viewing

5. **File Management**
   - [ ] Upload profile image
   - [ ] Upload paper files
   - [ ] File download functionality
   - [ ] File deletion
   - [ ] File type validation

### API Testing

Use tools like **Postman** or **curl** to test API endpoints:

```bash
# Test user registration
curl -X POST http://localhost:5000/api/auth/register \
  -H "Content-Type: application/json" \
  -d '{
    "email": "test@example.com",
    "password": "SecurePass123!",
    "firstName": "Test",
    "lastName": "User"
  }'

# Test login
curl -X POST http://localhost:5000/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{
    "email": "test@example.com",
    "password": "SecurePass123!"
  }'
```

## 🚀 Deployment

### Production Build

1. **Environment Configuration**
   ```bash
   NODE_ENV=production
   JWT_SECRET=secure-production-secret
   DATABASE_URL=postgresql://user:pass@host:5432/dbname
   EMAIL_USER=your-email@domain.com
   EMAIL_PASSWORD=secure-app-password
   ```

2. **Build the application**
   ```bash
   npm run build
   ```

3. **Database Migration**
   ```bash
   psql production_database < database/schema.sql
   ```

4. **Start production server**
   ```bash
   npm start
   ```

### Docker Deployment (Recommended)

1. **Create Dockerfile**
   ```dockerfile
   FROM node:18-alpine
   WORKDIR /app
   COPY package*.json ./
   RUN npm ci --only=production
   COPY . .
   RUN npm run build
   EXPOSE 5000
   CMD ["npm", "start"]
   ```

2. **Docker Compose**
   ```yaml
   version: '3.8'
   services:
     app:
       build: .
       ports:
         - "5000:5000"
       environment:
         - NODE_ENV=production
         - DB_HOST=db
       depends_on:
         - db
     
     db:
       image: postgres:14
       environment:
         POSTGRES_DB: conference_management
         POSTGRES_USER: postgres
         POSTGRES_PASSWORD: password
       volumes:
         - postgres_data:/var/lib/postgresql/data
   
   volumes:
     postgres_data:
   ```

## 🐛 Troubleshooting

### Common Issues

1. **Database Connection Error**
   ```bash
   # Check PostgreSQL is running
   pg_isready -h localhost -p 5432
   
   # Verify database exists
   psql -U postgres -l | grep conference_management
   ```

2. **Email Not Sending**
   - Verify Gmail app password is correct
   - Check 2FA is enabled
   - Ensure correct EMAIL_USER/EMAIL_PASSWORD

3. **File Upload Issues**
   - Check upload directory permissions
   - Verify MAX_FILE_SIZE_MB setting
   - Check allowed file types configuration

4. **Frontend Build Issues**
   ```bash
   # Clear node modules and reinstall
   rm -rf node_modules client/node_modules
   npm install
   cd client && npm install
   ```

## 🤝 Contributing

1. **Fork the repository**
2. **Create a feature branch** (`git checkout -b feature/amazing-feature`)
3. **Commit your changes** (`git commit -m 'Add amazing feature'`)
4. **Push to the branch** (`git push origin feature/amazing-feature`)
5. **Open a Pull Request**

### Development Guidelines
- Follow TypeScript best practices
- Use ESLint and Prettier for code formatting
- Write comprehensive tests for new features
- Update documentation for API changes
- Follow semantic commit messages

## 📄 License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## 👥 Support

For support and questions:
- **Email**: bigfatty@gmail.com
- **Documentation**: This README and inline code comments
- **Issues**: GitHub Issues for bug reports and feature requests

## 🎯 Future Enhancements

### Planned Features
- **Payment Integration** - Stripe/PayPal for conference fees
- **Advanced Analytics** - Conference statistics and reporting
- **Mobile Application** - React Native mobile app
- **Integration APIs** - ORCID, Google Scholar, arXiv integration
- **Multi-language Support** - Internationalization
- **Advanced Review Analytics** - AI-powered review insights
- **Conference Templates** - Pre-configured conference settings
- **Bulk Operations** - Mass email, bulk reviewer assignment
- **Real-time Notifications** - WebSocket-based live updates
- **Advanced File Handling** - PDF processing, plagiarism detection

### Technical Improvements
- **GraphQL API** - More efficient data fetching
- **Microservices Architecture** - Scalable system design
- **Kubernetes Deployment** - Container orchestration
- **CDN Integration** - Global file distribution
- **Advanced Caching** - Redis-based caching layer
- **Database Optimization** - Advanced indexing and query optimization

---

**Built with ❤️ by MiniMax Agent**

*A comprehensive solution for modern academic conference management.*