-- Conference Management System Database Schema
-- Created: 2025-11-11

-- Enable UUID extension
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- Users table
CREATE TABLE users (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    email VARCHAR(255) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    first_name VARCHAR(100) NOT NULL,
    last_name VARCHAR(100) NOT NULL,
    affiliation VARCHAR(255),
    orcid_id VARCHAR(50),
    biography TEXT,
    profile_image_url VARCHAR(500),
    email_verified BOOLEAN DEFAULT FALSE,
    email_verification_token VARCHAR(255),
    password_reset_token VARCHAR(255),
    password_reset_expires TIMESTAMP,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- User roles enum
CREATE TYPE user_role AS ENUM ('admin', 'author', 'reviewer', 'attendee');

-- Conference table
CREATE TABLE conferences (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name VARCHAR(255) NOT NULL,
    acronym VARCHAR(50) NOT NULL,
    description TEXT,
    website_url VARCHAR(500),
    start_date DATE NOT NULL,
    end_date DATE NOT NULL,
    submission_deadline TIMESTAMP NOT NULL,
    review_deadline TIMESTAMP NOT NULL,
    acceptance_notification_date TIMESTAMP NOT NULL,
    camera_ready_deadline TIMESTAMP NOT NULL,
    registration_deadline TIMESTAMP,
    max_submissions INTEGER DEFAULT 1,
    allow_multiple_tracks BOOLEAN DEFAULT FALSE,
    review_type VARCHAR(50) DEFAULT 'single_blind',
    status VARCHAR(50) DEFAULT 'draft',
    created_by UUID REFERENCES users(id),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Conference tracks
CREATE TABLE conference_tracks (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    conference_id UUID REFERENCES conferences(id) ON DELETE CASCADE,
    name VARCHAR(255) NOT NULL,
    description TEXT,
    chair_name VARCHAR(255),
    chair_email VARCHAR(255),
    max_papers INTEGER,
    submission_guidelines TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- User conference roles
CREATE TABLE user_conference_roles (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID REFERENCES users(id) ON DELETE CASCADE,
    conference_id UUID REFERENCES conferences(id) ON DELETE CASCADE,
    role user_role NOT NULL,
    track_id UUID REFERENCES conference_tracks(id) ON DELETE SET NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(user_id, conference_id, role)
);

-- Paper submissions
CREATE TYPE paper_status AS ENUM ('submitted', 'under_review', 'accepted', 'rejected', 'needs_revision', 'withdrawn');

CREATE TABLE papers (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    title VARCHAR(500) NOT NULL,
    abstract TEXT NOT NULL,
    keywords TEXT[],
    conference_id UUID REFERENCES conferences(id) ON DELETE CASCADE,
    track_id UUID REFERENCES conference_tracks(id) ON DELETE SET NULL,
    corresponding_author_id UUID REFERENCES users(id) ON DELETE CASCADE,
    paper_file_url VARCHAR(500),
    camera_ready_file_url VARCHAR(500),
    status paper_status DEFAULT 'submitted',
    submission_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    decision_date TIMESTAMP,
    reviewer_score DECIMAL(3,2),
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Paper authors (many-to-many)
CREATE TABLE paper_authors (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    paper_id UUID REFERENCES papers(id) ON DELETE CASCADE,
    author_id UUID REFERENCES users(id) ON DELETE CASCADE,
    is_corresponding_author BOOLEAN DEFAULT FALSE,
    author_order INTEGER NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(paper_id, author_id)
);

-- Review assignments
CREATE TABLE review_assignments (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    paper_id UUID REFERENCES papers(id) ON DELETE CASCADE,
    reviewer_id UUID REFERENCES users(id) ON DELETE CASCADE,
    assigned_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    due_date TIMESTAMP NOT NULL,
    completed_date TIMESTAMP,
    status VARCHAR(50) DEFAULT 'assigned',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(paper_id, reviewer_id)
);

-- Review criteria
CREATE TABLE review_criteria (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    conference_id UUID REFERENCES conferences(id) ON DELETE CASCADE,
    name VARCHAR(255) NOT NULL,
    description TEXT,
    weight DECIMAL(3,2) DEFAULT 1.0,
    max_score INTEGER NOT NULL,
    is_required BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Reviews
CREATE TABLE reviews (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    assignment_id UUID REFERENCES review_assignments(id) ON DELETE CASCADE,
    overall_score INTEGER NOT NULL,
    recommendation VARCHAR(50),
    confidence_level INTEGER,
    strength_points TEXT,
    weakness_points TEXT,
    detailed_comments TEXT,
    confidential_comments TEXT,
    is_submitted BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Review scores
CREATE TABLE review_scores (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    review_id UUID REFERENCES reviews(id) ON DELETE CASCADE,
    criteria_id UUID REFERENCES review_criteria(id) ON DELETE CASCADE,
    score INTEGER NOT NULL,
    comments TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(review_id, criteria_id)
);

-- Reviewer expertise
CREATE TABLE reviewer_expertise (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID REFERENCES users(id) ON DELETE CASCADE,
    subject_area VARCHAR(255) NOT NULL,
    keywords TEXT[],
    experience_level VARCHAR(50) DEFAULT 'intermediate',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Conference registrations
CREATE TYPE registration_status AS ENUM ('pending', 'confirmed', 'cancelled', 'refunded');

CREATE TABLE conference_registrations (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID REFERENCES users(id) ON DELETE CASCADE,
    conference_id UUID REFERENCES conferences(id) ON DELETE CASCADE,
    registration_type VARCHAR(100) NOT NULL,
    dietary_requirements TEXT,
    special_needs TEXT,
    emergency_contact_name VARCHAR(255),
    emergency_contact_phone VARCHAR(50),
    registration_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    status registration_status DEFAULT 'pending',
    amount_paid DECIMAL(10,2) DEFAULT 0,
    payment_method VARCHAR(50),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(user_id, conference_id)
);

-- Email notifications
CREATE TABLE email_notifications (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID REFERENCES users(id) ON DELETE CASCADE,
    conference_id UUID REFERENCES conferences(id) ON DELETE CASCADE,
    type VARCHAR(100) NOT NULL,
    subject VARCHAR(500) NOT NULL,
    content TEXT NOT NULL,
    sent_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    is_read BOOLEAN DEFAULT FALSE
);

-- System settings
CREATE TABLE system_settings (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    key VARCHAR(100) UNIQUE NOT NULL,
    value TEXT NOT NULL,
    description TEXT,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Insert default review criteria
INSERT INTO review_criteria (conference_id, name, description, weight, max_score) 
VALUES 
    (uuid_generate_v4(), 'Technical Quality', 'Clarity, correctness, and technical depth of the work', 1.0, 5),
    (uuid_generate_v4(), 'Originality', 'Novelty and contribution to the field', 1.0, 5),
    (uuid_generate_v4(), 'Significance', 'Importance and impact of the work', 1.0, 5),
    (uuid_generate_v4(), 'Presentation', 'Clarity of writing, organization, and figures', 1.0, 5);

-- Insert system settings
INSERT INTO system_settings (key, value, description) VALUES
    ('max_file_size_mb', '50', 'Maximum file upload size in MB'),
    ('allowed_file_types', 'pdf,docx', 'Allowed file types for uploads'),
    ('session_timeout_hours', '24', 'User session timeout in hours'),
    ('email_sender', 'bigfatty@gmail.com', 'Default email sender address');

-- Create indexes for better performance
CREATE INDEX idx_users_email ON users(email);
CREATE INDEX idx_conferences_status ON conferences(status);
CREATE INDEX idx_papers_conference_status ON papers(conference_id, status);
CREATE INDEX idx_papers_author ON papers(corresponding_author_id);
CREATE INDEX idx_review_assignments_reviewer ON review_assignments(reviewer_id);
CREATE INDEX idx_review_assignments_paper ON review_assignments(paper_id);
CREATE INDEX idx_reviews_assignment ON reviews(assignment_id);
CREATE INDEX idx_conference_registrations_user ON conference_registrations(user_id);
CREATE INDEX idx_conference_registrations_conference ON conference_registrations(conference_id);

-- Create updated_at trigger function
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$ language 'plpgsql';

-- Create triggers for updated_at
CREATE TRIGGER update_users_updated_at BEFORE UPDATE ON users FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_conferences_updated_at BEFORE UPDATE ON conferences FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_papers_updated_at BEFORE UPDATE ON papers FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_reviews_updated_at BEFORE UPDATE ON reviews FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();