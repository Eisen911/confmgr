import nodemailer from 'nodemailer';
import Database from '../database/connection';

export interface EmailData {
  to: string;
  subject: string;
  html: string;
  text?: string;
  type: string;
  userId?: string;
  conferenceId?: string;
}

export class EmailService {
  private static instance: EmailService;
  private transporter: nodemailer.Transporter;

  private constructor() {
    this.transporter = nodemailer.createTransporter({
      service: 'gmail',
      auth: {
        user: process.env.EMAIL_USER || 'bigfatty@gmail.com',
        pass: process.env.EMAIL_PASSWORD || 'your-app-password'
      }
    });
  }

  public static getInstance(): EmailService {
    if (!EmailService.instance) {
      EmailService.instance = new EmailService();
    }
    return EmailService.instance;
  }

  public async sendEmail(emailData: EmailData): Promise<boolean> {
    try {
      const mailOptions = {
        from: process.env.EMAIL_USER || 'bigfatty@gmail.com',
        to: emailData.to,
        subject: emailData.subject,
        html: emailData.html,
        text: emailData.text || this.stripHtml(emailData.html)
      };

      await this.transporter.sendMail(mailOptions);

      // Log the email notification
      if (emailData.userId) {
        const db = Database.getInstance();
        await db.query(
          `INSERT INTO email_notifications (user_id, conference_id, type, subject, content) 
           VALUES ($1, $2, $3, $4, $5)`,
          [emailData.userId, emailData.conferenceId, emailData.type, emailData.subject, emailData.html]
        );
      }

      console.log(`Email sent to: ${emailData.to}`);
      return true;
    } catch (error) {
      console.error('Email sending error:', error);
      return false;
    }
  }

  public async sendWelcomeEmail(user: any, verificationToken?: string): Promise<boolean> {
    const subject = 'Welcome to Conference Management System';
    let html = `
      <h2>Welcome, ${user.first_name}!</h2>
      <p>Thank you for registering with our Conference Management System.</p>
      <p>Your account has been created with the following details:</p>
      <ul>
        <li><strong>Name:</strong> ${user.first_name} ${user.last_name}</li>
        <li><strong>Email:</strong> ${user.email}</li>
        <li><strong>Affiliation:</strong> ${user.affiliation || 'Not provided'}</li>
      </ul>
    `;

    if (verificationToken) {
      html += `
        <p>Please verify your email address by clicking the link below:</p>
        <p><a href="${process.env.CLIENT_URL}/verify-email?token=${verificationToken}" style="background-color: #007BFF; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px;">Verify Email</a></p>
      `;
    }

    html += `
      <p>You can now start exploring conferences, submitting papers, and managing your academic work.</p>
      <p>Best regards,<br>The Conference Management Team</p>
    `;

    return await this.sendEmail({
      to: user.email,
      subject,
      html,
      type: 'welcome'
    });
  }

  public async sendPasswordResetEmail(user: any, resetToken: string): Promise<boolean> {
    const subject = 'Password Reset Request';
    const html = `
      <h2>Password Reset Request</h2>
      <p>Hello ${user.first_name},</p>
      <p>We received a request to reset your password for the Conference Management System.</p>
      <p>Click the link below to reset your password:</p>
      <p><a href="${process.env.CLIENT_URL}/reset-password?token=${resetToken}" style="background-color: #007BFF; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px;">Reset Password</a></p>
      <p>This link will expire in 1 hour.</p>
      <p>If you didn't request this, please ignore this email.</p>
      <p>Best regards,<br>The Conference Management Team</p>
    `;

    return await this.sendEmail({
      to: user.email,
      subject,
      html,
      type: 'password_reset',
      userId: user.id
    });
  }

  public async sendSubmissionConfirmationEmail(user: any, paper: any, conference: any): Promise<boolean> {
    const subject = `Paper Submission Confirmation - ${conference.name}`;
    const html = `
      <h2>Submission Confirmation</h2>
      <p>Hello ${user.first_name},</p>
      <p>Your paper has been successfully submitted to <strong>${conference.name}</strong>.</p>
      <div style="background-color: #f8f9fa; padding: 20px; border-radius: 8px; margin: 20px 0;">
        <h3>Paper Details:</h3>
        <p><strong>Title:</strong> ${paper.title}</p>
        <p><strong>Abstract:</strong> ${paper.abstract.substring(0, 200)}...</p>
        <p><strong>Status:</strong> <span style="background-color: #17a2b8; color: white; padding: 4px 8px; border-radius: 4px;">Submitted</span></p>
        <p><strong>Submission Date:</strong> ${new Date(paper.submission_date).toLocaleDateString()}</p>
      </div>
      <p>You will be notified of the review decision by ${new Date(conference.acceptance_notification_date).toLocaleDateString()}.</p>
      <p>You can track your submission status by logging into your account.</p>
      <p>Best regards,<br>The ${conference.name} Team</p>
    `;

    return await this.sendEmail({
      to: user.email,
      subject,
      html,
      type: 'submission_confirmation',
      userId: user.id,
      conferenceId: conference.id
    });
  }

  public async sendReviewAssignmentEmail(user: any, assignment: any, paper: any, conference: any): Promise<boolean> {
    const subject = `Review Assignment - ${conference.name}`;
    const html = `
      <h2>Review Assignment</h2>
      <p>Hello ${user.first_name},</p>
      <p>You have been assigned to review a paper for <strong>${conference.name}</strong>.</p>
      <div style="background-color: #f8f9fa; padding: 20px; border-radius: 8px; margin: 20px 0;">
        <h3>Paper Details:</h3>
        <p><strong>Title:</strong> ${paper.title}</p>
        <p><strong>Abstract:</strong> ${paper.abstract.substring(0, 200)}...</p>
        <p><strong>Due Date:</strong> ${new Date(assignment.due_date).toLocaleDateString()}</p>
        <p><strong>Review Type:</strong> ${conference.review_type}</p>
      </div>
      <p>Please complete your review by the due date indicated above.</p>
      <p><a href="${process.env.CLIENT_URL}/review/${assignment.id}" style="background-color: #007BFF; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px;">Start Review</a></p>
      <p>Thank you for contributing to the review process.</p>
      <p>Best regards,<br>The ${conference.name} Team</p>
    `;

    return await this.sendEmail({
      to: user.email,
      subject,
      html,
      type: 'review_assignment',
      userId: user.id,
      conferenceId: conference.id
    });
  }

  public async sendDecisionNotificationEmail(user: any, paper: any, decision: string, conference: any): Promise<boolean> {
    const subject = `Paper Decision - ${conference.name}`;
    const statusColor = decision === 'accepted' ? '#28a745' : decision === 'rejected' ? '#dc3545' : '#ffc107';
    const statusText = decision === 'accepted' ? 'ACCEPTED' : decision === 'rejected' ? 'REJECTED' : 'NEEDS REVISION';
    
    const html = `
      <h2>Paper Decision Notification</h2>
      <p>Hello ${user.first_name},</p>
      <p>We are pleased to inform you about the decision for your paper submitted to <strong>${conference.name}</strong>.</p>
      <div style="background-color: ${statusColor}; color: white; padding: 20px; border-radius: 8px; margin: 20px 0; text-align: center;">
        <h2 style="margin: 0; color: white;">${statusText}</h2>
      </div>
      <div style="background-color: #f8f9fa; padding: 20px; border-radius: 8px; margin: 20px 0;">
        <h3>Paper Details:</h3>
        <p><strong>Title:</strong> ${paper.title}</p>
        <p><strong>Decision Date:</strong> ${new Date(paper.decision_date).toLocaleDateString()}</p>
      </div>
      <p>${decision === 'accepted' ? 'Congratulations! Your paper has been accepted for presentation at the conference.' : 
              decision === 'rejected' ? 'We regret to inform you that your paper was not selected for inclusion in the conference.' : 
              'Your paper requires revisions before it can be considered for acceptance.'}</p>
      <p>Please log into your account to view the detailed review comments and take any necessary action.</p>
      <p>Best regards,<br>The ${conference.name} Team</p>
    `;

    return await this.sendEmail({
      to: user.email,
      subject,
      html,
      type: 'decision_notification',
      userId: user.id,
      conferenceId: conference.id
    });
  }

  private stripHtml(html: string): string {
    return html.replace(/<[^>]*>/g, '').replace(/&nbsp;/g, ' ').trim();
  }
}