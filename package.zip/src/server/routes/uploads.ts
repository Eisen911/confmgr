import { Router } from 'express';
import multer from 'multer';
import path from 'path';
import fs from 'fs';
import { authenticate } from '../middleware/auth';

const router = Router();

// Ensure upload directory exists
const uploadDir = path.join(__dirname, '../../uploads');
if (!fs.existsSync(uploadDir)) {
  fs.mkdirSync(uploadDir, { recursive: true });
}

// Configure multer for file uploads
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    const uploadType = req.params.type || 'general';
    const typeDir = path.join(uploadDir, uploadType);
    
    if (!fs.existsSync(typeDir)) {
      fs.mkdirSync(typeDir, { recursive: true });
    }
    
    cb(null, typeDir);
  },
  filename: (req, file, cb) => {
    const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
    const fileExtension = path.extname(file.originalname);
    const baseName = path.basename(file.originalname, fileExtension)
      .replace(/[^a-zA-Z0-9]/g, '_')
      .substring(0, 50);
    
    cb(null, `${baseName}_${uniqueSuffix}${fileExtension}`);
  }
});

// File filter function
const fileFilter = (req: any, file: any, cb: any) => {
  // Get allowed file types from environment or use defaults
  const allowedTypes = process.env.ALLOWED_FILE_TYPES?.split(',') || ['pdf', 'docx', 'doc'];
  const fileExtension = path.extname(file.originalname).toLowerCase().substring(1);
  
  if (allowedTypes.includes(fileExtension)) {
    cb(null, true);
  } else {
    cb(new Error(`File type .${fileExtension} is not allowed. Allowed types: ${allowedTypes.join(', ')}`), false);
  }
};

// Create multer instance
const upload = multer({
  storage,
  fileFilter,
  limits: {
    fileSize: parseInt(process.env.MAX_FILE_SIZE_MB || '50') * 1024 * 1024, // Convert MB to bytes
    files: 1
  }
});

// Upload paper file
router.post('/papers/:paperId', [
  authenticate,
  upload.single('file')
], async (req, res) => {
  try {
    const { paperId } = req.params;
    const userId = (req as any).user.id;

    if (!req.file) {
      return res.status(400).json({ error: 'No file provided' });
    }

    // Get file type from query parameter (paper_file or camera_ready_file)
    const fileType = req.query.type as string || 'paper_file';
    
    if (!['paper_file', 'camera_ready_file'].includes(fileType)) {
      return res.status(400).json({ error: 'Invalid file type' });
    }

    // Import database connection
    const Database = (await import('../database/connection')).default;
    const db = Database.getInstance();

    // Verify user owns the paper
    const paperResult = await db.query(
      'SELECT id, corresponding_author_id, status FROM papers WHERE id = $1',
      [paperId]
    );

    if (paperResult.rows.length === 0) {
      return res.status(404).json({ error: 'Paper not found' });
    }

    const paper = paperResult.rows[0];
    
    if (paper.corresponding_author_id !== userId) {
      return res.status(403).json({ error: 'You are not authorized to upload files for this paper' });
    }

    // Additional validation based on paper status
    if (fileType === 'paper_file' && paper.status !== 'submitted' && paper.status !== 'needs_revision') {
      return res.status(400).json({ error: 'Paper file can only be updated when paper is in submitted or needs revision status' });
    }

    if (fileType === 'camera_ready_file' && paper.status !== 'accepted') {
      return res.status(400).json({ error: 'Camera ready file can only be uploaded for accepted papers' });
    }

    // Construct file URL
    const fileUrl = `/uploads/papers/${req.file.filename}`;

    // Update paper record
    await db.query(
      `UPDATE papers SET ${fileType}_url = $1, updated_at = CURRENT_TIMESTAMP WHERE id = $2`,
      [fileUrl, paperId]
    );

    res.json({
      message: 'File uploaded successfully',
      file: {
        filename: req.file.filename,
        originalName: req.file.originalname,
        size: req.file.size,
        url: fileUrl,
        type: fileType
      }
    });
  } catch (error) {
    console.error('Upload paper file error:', error);
    
    // Clean up uploaded file if database operation fails
    if (req.file) {
      try {
        fs.unlinkSync(req.file.path);
      } catch (unlinkError) {
        console.error('Error cleaning up file:', unlinkError);
      }
    }
    
    if (error instanceof Error) {
      if (error.message.includes('File type')) {
        res.status(400).json({ error: error.message });
      } else if (error.message.includes('File too large')) {
        res.status(400).json({ error: 'File size exceeds the maximum allowed limit' });
      } else {
        res.status(500).json({ error: 'Internal server error' });
      }
    } else {
      res.status(500).json({ error: 'Internal server error' });
    }
  }
});

// Upload profile image
router.post('/profile-image', [
  authenticate,
  upload.single('file')
], async (req, res) => {
  try {
    const userId = (req as any).user.id;

    if (!req.file) {
      return res.status(400).json({ error: 'No file provided' });
    }

    // Import database connection
    const Database = (await import('../database/connection')).default;
    const db = Database.getInstance();

    // Get current profile image URL to delete old file
    const userResult = await db.query('SELECT profile_image_url FROM users WHERE id = $1', [userId]);
    const oldImageUrl = userResult.rows[0]?.profile_image_url;

    // Construct file URL
    const fileUrl = `/uploads/profile/${req.file.filename}`;

    // Update user record
    await db.query(
      'UPDATE users SET profile_image_url = $1, updated_at = CURRENT_TIMESTAMP WHERE id = $2',
      [fileUrl, userId]
    );

    // Delete old profile image if exists
    if (oldImageUrl) {
      try {
        const oldImagePath = path.join(__dirname, '../../', oldImageUrl);
        if (fs.existsSync(oldImagePath)) {
          fs.unlinkSync(oldImagePath);
        }
      } catch (unlinkError) {
        console.error('Error deleting old profile image:', unlinkError);
      }
    }

    res.json({
      message: 'Profile image uploaded successfully',
      file: {
        filename: req.file.filename,
        originalName: req.file.originalname,
        size: req.file.size,
        url: fileUrl
      }
    });
  } catch (error) {
    console.error('Upload profile image error:', error);
    
    // Clean up uploaded file if database operation fails
    if (req.file) {
      try {
        fs.unlinkSync(req.file.path);
      } catch (unlinkError) {
        console.error('Error cleaning up file:', unlinkError);
      }
    }
    
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Download file
router.get('/download/:type/:filename', [
  authenticate
], async (req, res) => {
  try {
    const { type, filename } = req.params;
    
    // Validate file type
    if (!['papers', 'profile', 'general'].includes(type)) {
      return res.status(400).json({ error: 'Invalid file type' });
    }

    // Security check: prevent path traversal
    if (filename.includes('..') || filename.includes('/') || filename.includes('\\')) {
      return res.status(400).json({ error: 'Invalid filename' });
    }

    const filePath = path.join(uploadDir, type, filename);

    if (!fs.existsSync(filePath)) {
      return res.status(404).json({ error: 'File not found' });
    }

    // Set appropriate headers
    res.setHeader('Content-Disposition', `attachment; filename="${filename}"`);
    res.setHeader('Content-Type', 'application/octet-stream');

    // Stream the file
    const fileStream = fs.createReadStream(filePath);
    fileStream.pipe(res);
  } catch (error) {
    console.error('Download file error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Delete file
router.delete('/:type/:filename', [
  authenticate
], async (req, res) => {
  try {
    const { type, filename } = req.params;
    const userId = (req as any).user.id;

    // Validate file type
    if (!['papers', 'profile', 'general'].includes(type)) {
      return res.status(400).json({ error: 'Invalid file type' });
    }

    // Security check: prevent path traversal
    if (filename.includes('..') || filename.includes('/') || filename.includes('\\')) {
      return res.status(400).json({ error: 'Invalid filename' });
    }

    const filePath = path.join(uploadDir, type, filename);

    if (!fs.existsSync(filePath)) {
      return res.status(404).json({ error: 'File not found' });
    }

    // Additional authorization checks based on file type
    if (type === 'papers') {
      // Check if user owns the paper associated with this file
      const Database = (await import('../database/connection')).default;
      const db = Database.getInstance();
      
      const paperResult = await db.query(`
        SELECT p.id, p.corresponding_author_id 
        FROM papers p 
        WHERE p.paper_file_url LIKE $1 OR p.camera_ready_file_url LIKE $1
      `, [`%${filename}%`]);

      if (paperResult.rows.length === 0) {
        return res.status(404).json({ error: 'Paper not found' });
      }

      const paper = paperResult.rows[0];
      if (paper.corresponding_author_id !== userId) {
        return res.status(403).json({ error: 'You are not authorized to delete this file' });
      }

      // Update paper record to remove file URL
      await db.query(
        'UPDATE papers SET paper_file_url = NULL, updated_at = CURRENT_TIMESTAMP WHERE id = $1',
        [paper.id]
      );
    } else if (type === 'profile') {
      // Check if user owns this profile image
      const Database = (await import('../database/connection')).default;
      const db = Database.getInstance();
      
      const userResult = await db.query(
        'SELECT id FROM users WHERE id = $1 AND profile_image_url LIKE $2',
        [userId, `%${filename}%`]
      );

      if (userResult.rows.length === 0) {
        return res.status(403).json({ error: 'You are not authorized to delete this file' });
      }

      // Update user record to remove profile image URL
      await db.query(
        'UPDATE users SET profile_image_url = NULL, updated_at = CURRENT_TIMESTAMP WHERE id = $1',
        [userId]
      );
    }

    // Delete the file
    fs.unlinkSync(filePath);

    res.json({ message: 'File deleted successfully' });
  } catch (error) {
    console.error('Delete file error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Get file info
router.get('/info/:type/:filename', [
  authenticate
], async (req, res) => {
  try {
    const { type, filename } = req.params;

    // Validate file type
    if (!['papers', 'profile', 'general'].includes(type)) {
      return res.status(400).json({ error: 'Invalid file type' });
    }

    // Security check: prevent path traversal
    if (filename.includes('..') || filename.includes('/') || filename.includes('\\')) {
      return res.status(400).json({ error: 'Invalid filename' });
    }

    const filePath = path.join(uploadDir, type, filename);

    if (!fs.existsSync(filePath)) {
      return res.status(404).json({ error: 'File not found' });
    }

    const stats = fs.statSync(filePath);
    const fileExtension = path.extname(filename).toLowerCase().substring(1);

    res.json({
      filename,
      size: stats.size,
      created: stats.birthtime,
      modified: stats.mtime,
      type: fileExtension,
      url: `/uploads/${type}/${filename}`
    });
  } catch (error) {
    console.error('Get file info error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

export default router;