import { Router } from 'express';
import { body, query, validationResult } from 'express-validator';
import Database from '../database/connection';
import { authenticate, requireRole } from '../middleware/auth';

const router = Router();
const db = Database.getInstance();

// Get user profile
router.get('/profile', authenticate, async (req, res) => {
  try {
    const userId = (req as any).user.id;

    const result = await db.query(`
      SELECT u.id, u.email, u.first_name, u.last_name, u.affiliation, 
             u.orcid_id, u.biography, u.profile_image_url, u.email_verified,
             u.created_at,
             COALESCE(
               array_agg(DISTINCT ucr.role) FILTER (WHERE ucr.role IS NOT NULL),
               '{}'
             ) as roles
      FROM users u
      LEFT JOIN user_conference_roles ucr ON u.id = ucr.user_id
      WHERE u.id = $1
      GROUP BY u.id
    `, [userId]);

    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'User not found' });
    }

    res.json({ user: result.rows[0] });
  } catch (error) {
    console.error('Get profile error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Update user profile
router.put('/profile', [
  authenticate,
  body('firstName').optional().isLength({ min: 2 }).trim().escape(),
  body('lastName').optional().isLength({ min: 2 }).trim().escape(),
  body('affiliation').optional().trim().escape(),
  body('orcidId').optional().matches(/^\d{4}-\d{4}-\d{4}-\d{3}[\dX]$/),
  body('biography').optional().trim()
], async (req, res) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ errors: errors.array() });
    }

    const userId = (req as any).user.id;
    const { firstName, lastName, affiliation, orcidId, biography } = req.body;

    const result = await db.query(`
      UPDATE users 
      SET first_name = COALESCE($1, first_name),
          last_name = COALESCE($2, last_name),
          affiliation = COALESCE($3, affiliation),
          orcid_id = COALESCE($4, orcid_id),
          biography = COALESCE($5, biography),
          updated_at = CURRENT_TIMESTAMP
      WHERE id = $6
      RETURNING id, email, first_name, last_name, affiliation, orcid_id, biography
    `, [firstName, lastName, affiliation, orcidId, biography, userId]);

    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'User not found' });
    }

    res.json({ 
      message: 'Profile updated successfully',
      user: result.rows[0]
    });
  } catch (error) {
    console.error('Update profile error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Get user conference roles
router.get('/conferences', authenticate, async (req, res) => {
  try {
    const userId = (req as any).user.id;

    const result = await db.query(`
      SELECT c.id, c.name, c.acronym, c.description, c.start_date, c.end_date,
             c.status, ucr.role, ct.name as track_name
      FROM user_conference_roles ucr
      JOIN conferences c ON ucr.conference_id = c.id
      LEFT JOIN conference_tracks ct ON ucr.track_id = ct.id
      WHERE ucr.user_id = $1
      ORDER BY c.start_date DESC
    `, [userId]);

    res.json({ conferences: result.rows });
  } catch (error) {
    console.error('Get user conferences error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Get all users (admin only)
router.get('/', [
  authenticate,
  requireRole(['admin'])
], async (req, res) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ errors: errors.array() });
    }

    const { page = 1, limit = 20, search, role } = req.query;
    const offset = (Number(page) - 1) * Number(limit);

    let whereClause = 'WHERE 1=1';
    const params: any[] = [limit, offset];

    if (search) {
      params.push(`%${search}%`);
      whereClause += ` AND (u.first_name ILIKE $${params.length} OR u.last_name ILIKE $${params.length} OR u.email ILIKE $${params.length})`;
    }

    const result = await db.query(`
      SELECT u.id, u.email, u.first_name, u.last_name, u.affiliation, 
             u.email_verified, u.created_at,
             COALESCE(
               array_agg(DISTINCT ucr.role) FILTER (WHERE ucr.role IS NOT NULL),
               '{}'
             ) as roles
      FROM users u
      LEFT JOIN user_conference_roles ucr ON u.id = ucr.user_id
      ${whereClause}
      GROUP BY u.id
      ORDER BY u.created_at DESC
      LIMIT $1 OFFSET $2
    `, params);

    // Get total count
    const countResult = await db.query(`
      SELECT COUNT(DISTINCT u.id) as total
      FROM users u
      LEFT JOIN user_conference_roles ucr ON u.id = ucr.user_id
      ${whereClause}
    `, params.slice(0, -2)); // Remove limit and offset

    res.json({
      users: result.rows,
      pagination: {
        page: Number(page),
        limit: Number(limit),
        total: countResult.rows[0].total,
        totalPages: Math.ceil(countResult.rows[0].total / Number(limit))
      }
    });
  } catch (error) {
    console.error('Get all users error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Get user by ID (admin only)
router.get('/:id', [
  authenticate,
  requireRole(['admin'])
], async (req, res) => {
  try {
    const { id } = req.params;

    const result = await db.query(`
      SELECT u.id, u.email, u.first_name, u.last_name, u.affiliation,
             u.orcid_id, u.biography, u.email_verified, u.created_at,
             COALESCE(
               array_agg(DISTINCT ucr.role) FILTER (WHERE ucr.role IS NOT NULL),
               '{}'
             ) as roles
      FROM users u
      LEFT JOIN user_conference_roles ucr ON u.id = ucr.user_id
      WHERE u.id = $1
      GROUP BY u.id
    `, [id]);

    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'User not found' });
    }

    res.json({ user: result.rows[0] });
  } catch (error) {
    console.error('Get user by ID error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Update user role (admin only)
router.put('/:id/role', [
  authenticate,
  requireRole(['admin']),
  body('role').isIn(['admin', 'author', 'reviewer', 'attendee']),
  body('conferenceId').optional().isUUID(),
  body('trackId').optional().isUUID()
], async (req, res) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ errors: errors.array() });
    }

    const { id } = req.params;
    const { role, conferenceId, trackId } = req.body;

    // Check if user exists
    const userResult = await db.query('SELECT id FROM users WHERE id = $1', [id]);
    if (userResult.rows.length === 0) {
      return res.status(404).json({ error: 'User not found' });
    }

    if (conferenceId) {
      // Check if conference exists
      const confResult = await db.query('SELECT id FROM conferences WHERE id = $1', [conferenceId]);
      if (confResult.rows.length === 0) {
        return res.status(404).json({ error: 'Conference not found' });
      }

      // Check if track exists if provided
      if (trackId) {
        const trackResult = await db.query('SELECT id FROM conference_tracks WHERE id = $1 AND conference_id = $2', [trackId, conferenceId]);
        if (trackResult.rows.length === 0) {
          return res.status(404).json({ error: 'Track not found' });
        }
      }

      // Insert or update user conference role
      await db.query(`
        INSERT INTO user_conference_roles (user_id, conference_id, role, track_id)
        VALUES ($1, $2, $3, $4)
        ON CONFLICT (user_id, conference_id, role)
        DO UPDATE SET track_id = EXCLUDED.track_id
      `, [id, conferenceId, role, trackId]);
    } else {
      // General role assignment (non-conference specific)
      await db.query(`
        INSERT INTO user_conference_roles (user_id, conference_id, role)
        VALUES ($1, NULL, $2)
        ON CONFLICT (user_id, conference_id, role)
        DO NOTHING
      `, [id, role]);
    }

    res.json({ message: 'User role updated successfully' });
  } catch (error) {
    console.error('Update user role error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Remove user role (admin only)
router.delete('/:id/role', [
  authenticate,
  requireRole(['admin']),
  body('role').isIn(['admin', 'author', 'reviewer', 'attendee']),
  body('conferenceId').optional().isUUID()
], async (req, res) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ errors: errors.array() });
    }

    const { id } = req.params;
    const { role, conferenceId } = req.body;

    await db.query(`
      DELETE FROM user_conference_roles 
      WHERE user_id = $1 AND role = $2 AND conference_id = $3
    `, [id, role, conferenceId || null]);

    res.json({ message: 'User role removed successfully' });
  } catch (error) {
    console.error('Remove user role error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

export default router;