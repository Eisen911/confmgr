import { Router } from 'express';
import { body, query, validationResult } from 'express-validator';
import Database from '../database/connection';
import { authenticate, requireRole } from '../middleware/auth';

const router = Router();
const db = Database.getInstance();

// Get all conferences
router.get('/', [
  query('status').optional().isIn(['draft', 'open', 'closed', 'completed']),
  query('page').optional().isInt({ min: 1 }),
  query('limit').optional().isInt({ min: 1, max: 100 })
], async (req, res) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ errors: errors.array() });
    }

    const { status, page = 1, limit = 20, search } = req.query;
    const offset = (Number(page) - 1) * Number(limit);

    let whereClause = 'WHERE 1=1';
    const params: any[] = [limit, offset];

    if (status) {
      params.push(status);
      whereClause += ` AND status = $${params.length}`;
    }

    if (search) {
      params.push(`%${search}%`);
      whereClause += ` AND (name ILIKE $${params.length} OR acronym ILIKE $${params.length})`;
    }

    const result = await db.query(`
      SELECT c.id, c.name, c.acronym, c.description, c.website_url,
             c.start_date, c.end_date, c.submission_deadline, c.review_deadline,
             c.acceptance_notification_date, c.camera_ready_deadline, c.status,
             c.max_submissions, c.allow_multiple_tracks, c.review_type,
             u.first_name || ' ' || u.last_name as created_by_name,
             COUNT(DISTINCT p.id) as paper_count
      FROM conferences c
      LEFT JOIN users u ON c.created_by = u.id
      LEFT JOIN papers p ON c.id = p.conference_id
      ${whereClause}
      GROUP BY c.id, u.first_name, u.last_name
      ORDER BY c.start_date DESC
      LIMIT $1 OFFSET $2
    `, params);

    // Get total count
    const countResult = await db.query(`
      SELECT COUNT(*) as total
      FROM conferences c
      ${whereClause}
    `, params.slice(0, -2));

    res.json({
      conferences: result.rows,
      pagination: {
        page: Number(page),
        limit: Number(limit),
        total: countResult.rows[0].total,
        totalPages: Math.ceil(countResult.rows[0].total / Number(limit))
      }
    });
  } catch (error) {
    console.error('Get conferences error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Get conference by ID
router.get('/:id', [
  query('includeTracks').optional().isBoolean()
], async (req, res) => {
  try {
    const { id } = req.params;
    const { includeTracks = false } = req.query;

    // Get conference details
    const result = await db.query(`
      SELECT c.*, 
             u.first_name || ' ' || u.last_name as created_by_name,
             COUNT(DISTINCT p.id) as paper_count,
             COUNT(DISTINCT ct.id) as track_count,
             COUNT(DISTINCT cr.id) as registration_count
      FROM conferences c
      LEFT JOIN users u ON c.created_by = u.id
      LEFT JOIN papers p ON c.id = p.conference_id
      LEFT JOIN conference_tracks ct ON c.id = ct.conference_id
      LEFT JOIN conference_registrations cr ON c.id = cr.conference_id
      WHERE c.id = $1
      GROUP BY c.id, u.first_name, u.last_name
    `, [id]);

    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Conference not found' });
    }

    const conference = result.rows[0];

    // Get tracks if requested
    if (includeTracks === 'true') {
      const tracksResult = await db.query(`
        SELECT ct.*, 
               COUNT(p.id) as paper_count,
               COUNT(ra.id) as reviewer_count
        FROM conference_tracks ct
        LEFT JOIN papers p ON ct.id = p.track_id
        LEFT JOIN review_assignments ra ON p.id = ra.paper_id
        WHERE ct.conference_id = $1
        GROUP BY ct.id
        ORDER BY ct.name
      `, [id]);
      
      conference.tracks = tracksResult.rows;
    }

    // Get registration statistics
    const statsResult = await db.query(`
      SELECT 
        COUNT(*) as total_registrations,
        COUNT(CASE WHEN status = 'confirmed' THEN 1 END) as confirmed_registrations,
        COUNT(CASE WHEN status = 'pending' THEN 1 END) as pending_registrations
      FROM conference_registrations
      WHERE conference_id = $1
    `, [id]);

    conference.registration_stats = statsResult.rows[0];

    res.json({ conference });
  } catch (error) {
    console.error('Get conference error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Create new conference (admin only)
router.post('/', [
  authenticate,
  requireRole(['admin']),
  body('name').isLength({ min: 3 }).trim().escape(),
  body('acronym').isLength({ min: 2, max: 10 }).trim().escape(),
  body('description').optional().trim(),
  body('websiteUrl').optional().isURL(),
  body('startDate').isISO8601(),
  body('endDate').isISO8601(),
  body('submissionDeadline').isISO8601(),
  body('reviewDeadline').isISO8601(),
  body('acceptanceNotificationDate').isISO8601(),
  body('cameraReadyDeadline').isISO8601(),
  body('registrationDeadline').optional().isISO8601(),
  body('maxSubmissions').optional().isInt({ min: 1 }),
  body('allowMultipleTracks').optional().isBoolean(),
  body('reviewType').optional().isIn(['single_blind', 'double_blind', 'open'])
], async (req, res) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ errors: errors.array() });
    }

    const userId = (req as any).user.id;
    const {
      name, acronym, description, websiteUrl, startDate, endDate,
      submissionDeadline, reviewDeadline, acceptanceNotificationDate,
      cameraReadyDeadline, registrationDeadline, maxSubmissions = 1,
      allowMultipleTracks = false, reviewType = 'single_blind'
    } = req.body;

    // Validate dates
    const dates = [startDate, endDate, submissionDeadline, reviewDeadline, acceptanceNotificationDate, cameraReadyDeadline];
    if (registrationDeadline) dates.push(registrationDeadline);

    // Check if conference acronym already exists
    const existingConf = await db.query('SELECT id FROM conferences WHERE acronym = $1', [acronym]);
    if (existingConf.rows.length > 0) {
      return res.status(400).json({ error: 'Conference acronym already exists' });
    }

    const result = await db.query(`
      INSERT INTO conferences (
        name, acronym, description, website_url, start_date, end_date,
        submission_deadline, review_deadline, acceptance_notification_date,
        camera_ready_deadline, registration_deadline, max_submissions,
        allow_multiple_tracks, review_type, created_by
      ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, $15)
      RETURNING *
    `, [
      name, acronym, description, websiteUrl, startDate, endDate,
      submissionDeadline, reviewDeadline, acceptanceNotificationDate,
      cameraReadyDeadline, registrationDeadline, maxSubmissions,
      allowMultipleTracks, reviewType, userId
    ]);

    const conference = result.rows[0];

    // Create default review criteria for the conference
    const defaultCriteria = [
      { name: 'Technical Quality', description: 'Clarity, correctness, and technical depth', weight: 1.0, max_score: 5 },
      { name: 'Originality', description: 'Novelty and contribution to the field', weight: 1.0, max_score: 5 },
      { name: 'Significance', description: 'Importance and impact of the work', weight: 1.0, max_score: 5 },
      { name: 'Presentation', description: 'Clarity of writing, organization, and figures', weight: 1.0, max_score: 5 }
    ];

    for (const criteria of defaultCriteria) {
      await db.query(
        'INSERT INTO review_criteria (conference_id, name, description, weight, max_score) VALUES ($1, $2, $3, $4, $5)',
        [conference.id, criteria.name, criteria.description, criteria.weight, criteria.max_score]
      );
    }

    res.status(201).json({ 
      message: 'Conference created successfully',
      conference 
    });
  } catch (error) {
    console.error('Create conference error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Update conference (admin only)
router.put('/:id', [
  authenticate,
  requireRole(['admin']),
  body('name').optional().isLength({ min: 3 }).trim().escape(),
  body('acronym').optional().isLength({ min: 2, max: 10 }).trim().escape(),
  body('description').optional().trim(),
  body('websiteUrl').optional().isURL(),
  body('startDate').optional().isISO8601(),
  body('endDate').optional().isISO8601(),
  body('submissionDeadline').optional().isISO8601(),
  body('reviewDeadline').optional().isISO8601(),
  body('acceptanceNotificationDate').optional().isISO8601(),
  body('cameraReadyDeadline').optional().isISO8601(),
  body('registrationDeadline').optional().isISO8601(),
  body('maxSubmissions').optional().isInt({ min: 1 }),
  body('allowMultipleTracks').optional().isBoolean(),
  body('reviewType').optional().isIn(['single_blind', 'double_blind', 'open']),
  body('status').optional().isIn(['draft', 'open', 'closed', 'completed'])
], async (req, res) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ errors: errors.array() });
    }

    const { id } = req.params;
    const updateData = req.body;

    // Check if conference exists
    const existingConf = await db.query('SELECT id FROM conferences WHERE id = $1', [id]);
    if (existingConf.rows.length === 0) {
      return res.status(404).json({ error: 'Conference not found' });
    }

    // Check if acronym exists for another conference
    if (updateData.acronym) {
      const acronymCheck = await db.query('SELECT id FROM conferences WHERE acronym = $1 AND id != $2', [updateData.acronym, id]);
      if (acronymCheck.rows.length > 0) {
        return res.status(400).json({ error: 'Conference acronym already exists' });
      }
    }

    // Build dynamic update query
    const allowedFields = [
      'name', 'acronym', 'description', 'website_url', 'start_date', 'end_date',
      'submission_deadline', 'review_deadline', 'acceptance_notification_date',
      'camera_ready_deadline', 'registration_deadline', 'max_submissions',
      'allow_multiple_tracks', 'review_type', 'status'
    ];

    const updates: string[] = [];
    const values: any[] = [];
    let paramCount = 1;

    for (const [key, value] of Object.entries(updateData)) {
      if (allowedFields.includes(key)) {
        const dbKey = key.replace(/([A-Z])/g, '_$1').toLowerCase();
        updates.push(`${dbKey} = $${paramCount}`);
        values.push(value);
        paramCount++;
      }
    }

    if (updates.length === 0) {
      return res.status(400).json({ error: 'No valid fields to update' });
    }

    values.push(id); // Add conference ID for WHERE clause

    const result = await db.query(`
      UPDATE conferences 
      SET ${updates.join(', ')}, updated_at = CURRENT_TIMESTAMP
      WHERE id = $${paramCount}
      RETURNING *
    `, values);

    res.json({
      message: 'Conference updated successfully',
      conference: result.rows[0]
    });
  } catch (error) {
    console.error('Update conference error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Delete conference (admin only)
router.delete('/:id', [
  authenticate,
  requireRole(['admin'])
], async (req, res) => {
  try {
    const { id } = req.params;

    // Check if conference exists and has no papers
    const result = await db.query('SELECT id, name FROM conferences WHERE id = $1', [id]);
    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Conference not found' });
    }

    // Check for existing papers
    const papersCount = await db.query('SELECT COUNT(*) as count FROM papers WHERE conference_id = $1', [id]);
    if (papersCount.rows[0].count > 0) {
      return res.status(400).json({ error: 'Cannot delete conference with existing papers' });
    }

    await db.query('DELETE FROM conferences WHERE id = $1', [id]);

    res.json({ message: 'Conference deleted successfully' });
  } catch (error) {
    console.error('Delete conference error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Get conference tracks
router.get('/:id/tracks', async (req, res) => {
  try {
    const { id } = req.params;

    const result = await db.query(`
      SELECT ct.*, 
             COUNT(p.id) as paper_count,
             COUNT(ra.id) as reviewer_count
      FROM conference_tracks ct
      LEFT JOIN papers p ON ct.id = p.track_id
      LEFT JOIN review_assignments ra ON p.id = ra.paper_id
      WHERE ct.conference_id = $1
      GROUP BY ct.id
      ORDER BY ct.name
    `, [id]);

    res.json({ tracks: result.rows });
  } catch (error) {
    console.error('Get conference tracks error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Create track (admin only)
router.post('/:id/tracks', [
  authenticate,
  requireRole(['admin']),
  body('name').isLength({ min: 2 }).trim().escape(),
  body('description').optional().trim(),
  body('chairName').optional().trim().escape(),
  body('chairEmail').optional().isEmail(),
  body('maxPapers').optional().isInt({ min: 1 }),
  body('submissionGuidelines').optional().trim()
], async (req, res) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ errors: errors.array() });
    }

    const { id } = req.params;
    const { name, description, chairName, chairEmail, maxPapers, submissionGuidelines } = req.body;

    // Check if conference exists
    const confResult = await db.query('SELECT id FROM conferences WHERE id = $1', [id]);
    if (confResult.rows.length === 0) {
      return res.status(404).json({ error: 'Conference not found' });
    }

    const result = await db.query(`
      INSERT INTO conference_tracks (
        conference_id, name, description, chair_name, chair_email, 
        max_papers, submission_guidelines
      ) VALUES ($1, $2, $3, $4, $5, $6, $7)
      RETURNING *
    `, [id, name, description, chairName, chairEmail, maxPapers, submissionGuidelines]);

    res.status(201).json({
      message: 'Track created successfully',
      track: result.rows[0]
    });
  } catch (error) {
    console.error('Create track error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

export default router;