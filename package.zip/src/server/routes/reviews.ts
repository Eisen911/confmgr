import { Router } from 'express';
import { body, query, validationResult } from 'express-validator';
import Database from '../database/connection';
import { authenticate, requireRole } from '../middleware/auth';
import { EmailService } from '../services/email';

const router = Router();
const db = Database.getInstance();
const emailService = EmailService.getInstance();

// Get review assignments for current user
router.get('/assignments', [
  authenticate,
  requireRole(['reviewer']),
  query('status').optional().isIn(['assigned', 'completed', 'overdue']),
  query('page').optional().isInt({ min: 1 }),
  query('limit').optional().isInt({ min: 1, max: 100 })
], async (req, res) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ errors: errors.array() });
    }

    const userId = (req as any).user.id;
    const { status, page = 1, limit = 20 } = req.query;
    const offset = (Number(page) - 1) * Number(limit);

    let whereClause = 'WHERE ra.reviewer_id = $1';
    const params: any[] = [userId, limit, offset];

    if (status === 'overdue') {
      whereClause += ' AND ra.due_date < CURRENT_TIMESTAMP AND ra.completed_date IS NULL';
    } else if (status === 'completed') {
      whereClause += ' AND ra.completed_date IS NOT NULL';
    } else if (status === 'assigned') {
      whereClause += ' AND ra.completed_date IS NULL';
    }

    const result = await db.query(`
      SELECT ra.id as assignment_id, ra.assigned_date, ra.due_date, ra.completed_date,
             p.id as paper_id, p.title, p.abstract, p.status as paper_status,
             c.name as conference_name, c.acronym as conference_acronym,
             ct.name as track_name,
             u.first_name || ' ' || u.last_name as author_name,
             r.id as review_id, r.overall_score, r.is_submitted
      FROM review_assignments ra
      JOIN papers p ON ra.paper_id = p.id
      JOIN conferences c ON p.conference_id = c.id
      LEFT JOIN conference_tracks ct ON p.track_id = ct.id
      LEFT JOIN users u ON p.corresponding_author_id = u.id
      LEFT JOIN reviews r ON ra.id = r.assignment_id
      ${whereClause}
      ORDER BY 
        CASE WHEN ra.due_date < CURRENT_TIMESTAMP AND ra.completed_date IS NULL THEN 1 ELSE 0 END DESC,
        ra.due_date ASC
      LIMIT $2 OFFSET $3
    `, params);

    // Get total count
    const countResult = await db.query(`
      SELECT COUNT(*) as total
      FROM review_assignments ra
      ${whereClause}
    `, params.slice(0, -2));

    res.json({
      assignments: result.rows,
      pagination: {
        page: Number(page),
        limit: Number(limit),
        total: countResult.rows[0].total,
        totalPages: Math.ceil(countResult.rows[0].total / Number(limit))
      }
    });
  } catch (error) {
    console.error('Get review assignments error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Get review assignment details
router.get('/assignments/:id', [
  authenticate,
  requireRole(['reviewer'])
], async (req, res) => {
  try {
    const { id } = req.params;
    const userId = (req as any).user.id;

    // Get assignment details
    const result = await db.query(`
      SELECT ra.*, 
             p.id as paper_id, p.title, p.abstract, p.keywords, p.status as paper_status,
             c.id as conference_id, c.name as conference_name, c.review_type, c.description as conference_description,
             ct.name as track_name, ct.submission_guidelines,
             u.first_name || ' ' || u.last_name as author_name, u.affiliation as author_affiliation,
             r.id as review_id, r.overall_score, r.recommendation, r.confidence_level,
             r.strength_points, r.weakness_points, r.detailed_comments, r.confidential_comments, r.is_submitted
      FROM review_assignments ra
      JOIN papers p ON ra.paper_id = p.id
      JOIN conferences c ON p.conference_id = c.id
      LEFT JOIN conference_tracks ct ON p.track_id = ct.id
      LEFT JOIN users u ON p.corresponding_author_id = u.id
      LEFT JOIN reviews r ON ra.id = r.assignment_id
      WHERE ra.id = $1 AND ra.reviewer_id = $2
    `, [id, userId]);

    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Review assignment not found' });
    }

    const assignment = result.rows[0];

    // Get review criteria for the conference
    const criteriaResult = await db.query(`
      SELECT rc.id, rc.name, rc.description, rc.weight, rc.max_score,
             rs.score as reviewer_score, rs.comments as reviewer_comments
      FROM review_criteria rc
      LEFT JOIN review_scores rs ON rc.id = rs.criteria_id 
        AND rs.review_id = $1
      WHERE rc.conference_id = $2
      ORDER BY rc.name
    `, [assignment.review_id, assignment.conference_id]);

    assignment.review_criteria = criteriaResult.rows;

    // Get authors of the paper
    const authorsResult = await db.query(`
      SELECT pa.author_order, u.first_name, u.last_name, u.affiliation, 
             pa.is_corresponding_author
      FROM paper_authors pa
      JOIN users u ON pa.author_id = u.id
      WHERE pa.paper_id = $1
      ORDER BY pa.author_order
    `, [assignment.paper_id]);
    
    assignment.authors = authorsResult.rows;

    res.json({ assignment });
  } catch (error) {
    console.error('Get review assignment error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Create or update review
router.post('/assignments/:id/review', [
  authenticate,
  requireRole(['reviewer']),
  body('overallScore').isInt({ min: 1, max: 5 }),
  body('recommendation').isIn(['accept', 'minor_revision', 'major_revision', 'reject']),
  body('confidenceLevel').optional().isInt({ min: 1, max: 5 }),
  body('strengthPoints').optional().trim(),
  body('weaknessPoints').optional().trim(),
  body('detailedComments').optional().trim(),
  body('confidentialComments').optional().trim(),
  body('criteriaScores').isArray(),
  body('criteriaScores.*.criteriaId').isUUID(),
  body('criteriaScores.*.score').isInt({ min: 1 }),
  body('criteriaScores.*.comments').optional().trim()
], async (req, res) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ errors: errors.array() });
    }

    const { id } = req.params;
    const userId = (req as any).user.id;
    const {
      overallScore, recommendation, confidenceLevel, strengthPoints,
      weaknessPoints, detailedComments, confidentialComments, criteriaScores
    } = req.body;

    // Check if assignment exists and belongs to user
    const assignmentResult = await db.query(
      'SELECT * FROM review_assignments WHERE id = $1 AND reviewer_id = $2',
      [id, userId]
    );

    if (assignmentResult.rows.length === 0) {
      return res.status(404).json({ error: 'Review assignment not found' });
    }

    const assignment = assignmentResult.rows[0];

    // Check if assignment is still valid (not completed and not overdue for submission)
    if (assignment.completed_date) {
      return res.status(400).json({ error: 'Review has already been submitted' });
    }

    // Validate criteria scores
    const criteriaIds = criteriaScores.map((c: any) => c.criteriaId);
    const criteriaResult = await db.query(`
      SELECT id, name, max_score FROM review_criteria 
      WHERE id = ANY($1::uuid[]) AND conference_id = $2
    `, [criteriaIds, assignment.paper_id]);

    if (criteriaResult.rows.length !== criteriaScores.length) {
      return res.status(400).json({ error: 'Invalid review criteria provided' });
    }

    // Validate score ranges
    for (const criteriaScore of criteriaScores) {
      const criteria = criteriaResult.rows.find((c: any) => c.id === criteriaScore.criteriaId);
      if (criteria && (criteriaScore.score < 1 || criteriaScore.score > criteria.max_score)) {
        return res.status(400).json({ 
          error: `Invalid score for ${criteria.name}. Must be between 1 and ${criteria.max_score}` 
        });
      }
    }

    await db.transaction(async (client) => {
      // Create or update review
      const reviewResult = await client.query(`
        INSERT INTO reviews (
          assignment_id, overall_score, recommendation, confidence_level,
          strength_points, weakness_points, detailed_comments, confidential_comments, is_submitted
        ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, true)
        ON CONFLICT (assignment_id)
        DO UPDATE SET
          overall_score = EXCLUDED.overall_score,
          recommendation = EXCLUDED.recommendation,
          confidence_level = EXCLUDED.confidence_level,
          strength_points = EXCLUDED.strength_points,
          weakness_points = EXCLUDED.weakness_points,
          detailed_comments = EXCLUDED.detailed_comments,
          confidential_comments = EXCLUDED.confidential_comments,
          is_submitted = EXCLUDED.is_submitted,
          updated_at = CURRENT_TIMESTAMP
        RETURNING *
      `, [
        id, overallScore, recommendation, confidenceLevel,
        strengthPoints, weaknessPoints, detailedComments, confidentialComments
      ]);

      const review = reviewResult.rows[0];

      // Clear existing criteria scores
      await client.query('DELETE FROM review_scores WHERE review_id = $1', [review.id]);

      // Insert new criteria scores
      for (const criteriaScore of criteriaScores) {
        await client.query(`
          INSERT INTO review_scores (review_id, criteria_id, score, comments)
          VALUES ($1, $2, $3, $4)
        `, [review.id, criteriaScore.criteriaId, criteriaScore.score, criteriaScore.comments]);
      }

      // Mark assignment as completed
      await client.query(
        'UPDATE review_assignments SET completed_date = CURRENT_TIMESTAMP, status = $1 WHERE id = $2',
        ['completed', id]
      );

      // Check if all reviews for the paper are completed
      const totalAssignments = await client.query(
        'SELECT COUNT(*) as total FROM review_assignments WHERE paper_id = $1',
        [assignment.paper_id]
      );

      const completedReviews = await client.query(
        'SELECT COUNT(*) as completed FROM review_assignments WHERE paper_id = $1 AND completed_date IS NOT NULL',
        [assignment.paper_id]
      );

      if (Number(completedReviews.rows[0].completed) >= Number(totalAssignments.rows[0].total)) {
        // All reviews completed, update paper status
        await client.query(
          'UPDATE papers SET status = $1, updated_at = CURRENT_TIMESTAMP WHERE id = $2',
          ['under_review', assignment.paper_id]
        );
      }

      return review;
    });

    res.json({
      message: 'Review submitted successfully',
      review: { id: id, overallScore, recommendation, isSubmitted: true }
    });
  } catch (error) {
    console.error('Submit review error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Get review criteria for a conference
router.get('/criteria/:conferenceId', async (req, res) => {
  try {
    const { conferenceId } = req.params;

    const result = await db.query(`
      SELECT id, name, description, weight, max_score, is_required
      FROM review_criteria
      WHERE conference_id = $1
      ORDER BY name
    `, [conferenceId]);

    res.json({ criteria: result.rows });
  } catch (error) {
    console.error('Get review criteria error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Admin functions

// Assign reviewers to paper (admin only)
router.post('/assignments', [
  authenticate,
  requireRole(['admin']),
  body('paperId').isUUID(),
  body('reviewers').isArray({ min: 1 }),
  body('reviewers.*.reviewerId').isUUID(),
  body('reviewers.*.dueDate').isISO8601()
], async (req, res) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ errors: errors.array() });
    }

    const { paperId, reviewers } = req.body;

    // Check if paper exists
    const paperResult = await db.query('SELECT * FROM papers WHERE id = $1', [paperId]);
    if (paperResult.rows.length === 0) {
      return res.status(404).json({ error: 'Paper not found' });
    }

    const paper = paperResult.rows[0];

    // Check if reviewers exist and are valid reviewers
    const reviewerIds = reviewers.map((r: any) => r.reviewerId);
    const usersResult = await db.query(
      'SELECT id, first_name, last_name FROM users WHERE id = ANY($1::uuid[])',
      [reviewerIds]
    );

    if (usersResult.rows.length !== reviewerIds.length) {
      return res.status(400).json({ error: 'One or more reviewers not found' });
    }

    const assignedReviews = [];
    
    await db.transaction(async (client) => {
      for (const reviewer of reviewers) {
        // Check if reviewer is already assigned to this paper
        const existingAssignment = await client.query(
          'SELECT id FROM review_assignments WHERE paper_id = $1 AND reviewer_id = $2',
          [paperId, reviewer.reviewerId]
        );

        if (existingAssignment.rows.length === 0) {
          // Create assignment
          const assignmentResult = await client.query(`
            INSERT INTO review_assignments (paper_id, reviewer_id, due_date)
            VALUES ($1, $2, $3)
            RETURNING *
          `, [paperId, reviewer.reviewerId, reviewer.dueDate]);

          assignedReviews.push(assignmentResult.rows[0]);

          // Send email notification to reviewer
          const reviewer = usersResult.rows.find(u => u.id === reviewer.reviewerId);
          if (reviewer) {
            await emailService.sendReviewAssignmentEmail(
              reviewer,
              assignmentResult.rows[0],
              paper,
              await client.query('SELECT * FROM conferences WHERE id = $1', [paper.conference_id])
            );
          }
        }
      }

      // Update paper status if not already under review
      if (paper.status === 'submitted') {
        await client.query(
          'UPDATE papers SET status = $1, updated_at = CURRENT_TIMESTAMP WHERE id = $2',
          ['under_review', paperId]
        );
      }

      return assignedReviews;
    });

    res.json({
      message: 'Reviewers assigned successfully',
      assignments: assignedReviews
    });
  } catch (error) {
    console.error('Assign reviewers error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Remove review assignment (admin only)
router.delete('/assignments/:id', [
  authenticate,
  requireRole(['admin'])
], async (req, res) => {
  try {
    const { id } = req.params;

    const result = await db.query(
      'DELETE FROM review_assignments WHERE id = $1 RETURNING paper_id',
      [id]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Review assignment not found' });
    }

    res.json({ message: 'Review assignment removed successfully' });
  } catch (error) {
    console.error('Remove review assignment error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Get paper reviews (admin only)
router.get('/papers/:id/reviews', [
  authenticate,
  requireRole(['admin'])
], async (req, res) => {
  try {
    const { id } = req.params;

    const result = await db.query(`
      SELECT r.*, u.first_name || ' ' || u.last_name as reviewer_name,
             rs.criteria_id, rs.score as criteria_score, rs.comments as criteria_comments,
             rc.name as criteria_name, rc.max_score as criteria_max_score
      FROM reviews r
      JOIN review_assignments ra ON r.assignment_id = ra.id
      JOIN users u ON ra.reviewer_id = u.id
      LEFT JOIN review_scores rs ON r.id = rs.review_id
      LEFT JOIN review_criteria rc ON rs.criteria_id = rc.id
      WHERE ra.paper_id = $1
      ORDER BY r.created_at, rc.name
    `, [id]);

    const reviews = result.rows;
    
    // Group scores by review
    const groupedReviews = reviews.reduce((acc, review) => {
      const existingReview = acc.find(r => r.id === review.id);
      if (existingReview) {
        existingReview.criteria_scores = existingReview.criteria_scores || [];
        if (review.criteria_id) {
          existingReview.criteria_scores.push({
            criteria_id: review.criteria_id,
            criteria_name: review.criteria_name,
            score: review.criteria_score,
            max_score: review.criteria_max_score,
            comments: review.criteria_comments
          });
        }
      } else {
        const newReview = {
          id: review.id,
          overall_score: review.overall_score,
          recommendation: review.recommendation,
          confidence_level: review.confidence_level,
          strength_points: review.strength_points,
          weakness_points: review.weakness_points,
          detailed_comments: review.detailed_comments,
          confidential_comments: review.confidential_comments,
          is_submitted: review.is_submitted,
          created_at: review.created_at,
          updated_at: review.updated_at,
          reviewer_name: review.reviewer_name,
          criteria_scores: review.criteria_id ? [{
            criteria_id: review.criteria_id,
            criteria_name: review.criteria_name,
            score: review.criteria_score,
            max_score: review.criteria_max_score,
            comments: review.criteria_comments
          }] : []
        };
        acc.push(newReview);
      }
      return acc;
    }, []);

    res.json({ reviews: groupedReviews });
  } catch (error) {
    console.error('Get paper reviews error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

export default router;