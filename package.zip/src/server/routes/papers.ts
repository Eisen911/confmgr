import { Router } from 'express';
import { body, query, validationResult } from 'express-validator';
import Database from '../database/connection';
import { authenticate, requireRole } from '../middleware/auth';
import { EmailService } from '../services/email';

const router = Router();
const db = Database.getInstance();
const emailService = EmailService.getInstance();

// Get papers (with role-based filtering)
router.get('/', [
  query('conferenceId').optional().isUUID(),
  query('status').optional().isIn(['submitted', 'under_review', 'accepted', 'rejected', 'needs_revision', 'withdrawn']),
  query('trackId').optional().isUUID(),
  query('page').optional().isInt({ min: 1 }),
  query('limit').optional().isInt({ min: 1, max: 100 })
], async (req, res) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ errors: errors.array() });
    }

    const { conferenceId, status, trackId, page = 1, limit = 20, search } = req.query;
    const user = (req as any).user;
    const offset = (Number(page) - 1) * Number(limit);

    let whereClause = 'WHERE 1=1';
    const params: any[] = [limit, offset];
    let userFilter = '';

    // Role-based filtering
    if (user && user.roles) {
      if (user.roles.includes('admin')) {
        // Admin can see all papers
        userFilter = '';
      } else if (user.roles.includes('author')) {
        // Author can see their own papers
        params.push(user.id);
        userFilter = ` AND p.corresponding_author_id = $${params.length}`;
      } else if (user.roles.includes('reviewer')) {
        // Reviewer can see papers assigned to them
        params.push(user.id);
        userFilter = ` AND p.id IN (SELECT paper_id FROM review_assignments WHERE reviewer_id = $${params.length})`;
      } else {
        // Other users can only see published papers
        whereClause += " AND p.status = 'accepted'";
      }
    } else {
      // No user, only published papers
      whereClause += " AND p.status = 'accepted'";
    }

    // Conference filter
    if (conferenceId) {
      params.push(conferenceId);
      whereClause += ` AND p.conference_id = $${params.length}`;
    }

    // Status filter
    if (status) {
      params.push(status);
      whereClause += ` AND p.status = $${params.length}`;
    }

    // Track filter
    if (trackId) {
      params.push(trackId);
      whereClause += ` AND p.track_id = $${params.length}`;
    }

    // Search filter
    if (search) {
      params.push(`%${search}%`);
      whereClause += ` AND (p.title ILIKE $${params.length} OR p.abstract ILIKE $${params.length})`;
    }

    const result = await db.query(`
      SELECT DISTINCT p.id, p.title, p.abstract, p.keywords, p.status,
             p.submission_date, p.decision_date, p.reviewer_score,
             c.name as conference_name, c.acronym as conference_acronym,
             ct.name as track_name,
             au.first_name || ' ' || au.last_name as author_name,
             au.affiliation as author_affiliation,
             COUNT(r.id) as review_count,
             COUNT(ra.id) as assignment_count
      FROM papers p
      JOIN conferences c ON p.conference_id = c.id
      JOIN users au ON p.corresponding_author_id = au.id
      LEFT JOIN conference_tracks ct ON p.track_id = ct.id
      LEFT JOIN reviews r ON p.id = r.assignment_id
      LEFT JOIN review_assignments ra ON p.id = ra.paper_id
      ${whereClause}
      ${userFilter}
      GROUP BY p.id, c.name, c.acronym, ct.name, au.first_name, au.last_name, au.affiliation
      ORDER BY p.submission_date DESC
      LIMIT $1 OFFSET $2
    `, params);

    // Get total count
    const countResult = await db.query(`
      SELECT COUNT(DISTINCT p.id) as total
      FROM papers p
      ${whereClause.replace('1=1', '1=1')}
      ${userFilter}
    `, params.slice(0, -2));

    res.json({
      papers: result.rows,
      pagination: {
        page: Number(page),
        limit: Number(limit),
        total: countResult.rows[0].total,
        totalPages: Math.ceil(countResult.rows[0].total / Number(limit))
      }
    });
  } catch (error) {
    console.error('Get papers error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Get paper by ID
router.get('/:id', async (req, res) => {
  try {
    const { id } = req.params;
    const user = (req as any).user;

    // Get paper details
    const result = await db.query(`
      SELECT p.*, 
             c.name as conference_name, c.acronym as conference_acronym,
             c.review_type, c.status as conference_status,
             ct.name as track_name, ct.id as track_id,
             au.first_name || ' ' || au.last_name as author_name,
             au.affiliation as author_affiliation,
             au.id as author_id
      FROM papers p
      JOIN conferences c ON p.conference_id = c.id
      LEFT JOIN conference_tracks ct ON p.track_id = ct.id
      LEFT JOIN users au ON p.corresponding_author_id = au.id
      WHERE p.id = $1
    `, [id]);

    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Paper not found' });
    }

    const paper = result.rows[0];

    // Check access permissions
    const canViewFullPaper = () => {
      if (!user) return false;
      if (user.roles?.includes('admin')) return true;
      if (paper.author_id === user.id) return true;
      if (user.roles?.includes('reviewer')) {
        // Check if user is assigned to review this paper
        const assignment = db.query('SELECT 1 FROM review_assignments WHERE paper_id = $1 AND reviewer_id = $2', [id, user.id]);
        return assignment.then(r => r.rows.length > 0);
      }
      return false;
    };

    const canViewFull = await canViewFullPaper();
    
    // If not authorized to view full paper, return limited information
    if (!canViewFull) {
      return res.json({
        paper: {
          id: paper.id,
          title: paper.title,
          keywords: paper.keywords,
          status: paper.status,
          submission_date: paper.submission_date,
          conference_name: paper.conference_name,
          conference_acronym: paper.conference_acronym,
          track_name: paper.track_name,
          author_name: 'Anonymous',
          reviewer_count: 0
        }
      });
    }

    // Get authors
    const authorsResult = await db.query(`
      SELECT pa.author_order, u.first_name, u.last_name, u.affiliation, 
             pa.is_corresponding_author
      FROM paper_authors pa
      JOIN users u ON pa.author_id = u.id
      WHERE pa.paper_id = $1
      ORDER BY pa.author_order
    `, [id]);
    
    paper.authors = authorsResult.rows;

    // Get reviews (only for reviewers and admins)
    let reviews = [];
    if (user?.roles?.includes('reviewer') || user?.roles?.includes('admin')) {
      const reviewsResult = await db.query(`
        SELECT r.*, u.first_name || ' ' || u.last_name as reviewer_name,
               rs.criteria_id, rs.score as criteria_score, rc.name as criteria_name
        FROM reviews r
        JOIN users u ON r.assignment_id IN (
          SELECT id FROM review_assignments WHERE reviewer_id = u.id
        )
        LEFT JOIN review_scores rs ON r.id = rs.review_id
        LEFT JOIN review_criteria rc ON rs.criteria_id = rc.id
        WHERE r.assignment_id IN (
          SELECT id FROM review_assignments WHERE paper_id = $1
        )
        ORDER BY r.created_at
      `, [id]);
      
      reviews = reviewsResult.rows;
    }

    // Get review assignments
    const assignmentsResult = await db.query(`
      SELECT ra.*, u.first_name || ' ' || u.last_name as reviewer_name,
             r.id as review_id, r.overall_score
      FROM review_assignments ra
      LEFT JOIN users u ON ra.reviewer_id = u.id
      LEFT JOIN reviews r ON ra.id = r.assignment_id
      WHERE ra.paper_id = $1
      ORDER BY ra.assigned_date
    `, [id]);
    
    paper.review_assignments = assignmentsResult.rows;
    paper.reviews = reviews;

    res.json({ paper });
  } catch (error) {
    console.error('Get paper error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Submit new paper
router.post('/', [
  authenticate,
  requireRole(['author']),
  body('title').isLength({ min: 10, max: 500 }).trim().escape(),
  body('abstract').isLength({ min: 50, max: 5000 }).trim(),
  body('keywords').optional().isArray(),
  body('conferenceId').isUUID(),
  body('trackId').optional().isUUID(),
  body('authors').isArray({ min: 1 }),
  body('authors.*.authorId').isUUID(),
  body('authors.*.isCorrespondingAuthor').optional().isBoolean(),
  body('authors.*.authorOrder').isInt({ min: 1 })
], async (req, res) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ errors: errors.array() });
    }

    const userId = (req as any).user.id;
    const { title, abstract, keywords, conferenceId, trackId, authors } = req.body;

    // Validate conference exists and is accepting submissions
    const confResult = await db.query(`
      SELECT id, name, submission_deadline, status, max_submissions 
      FROM conferences 
      WHERE id = $1
    `, [conferenceId]);

    if (confResult.rows.length === 0) {
      return res.status(404).json({ error: 'Conference not found' });
    }

    const conference = confResult.rows[0];
    
    if (conference.status !== 'open') {
      return res.status(400).json({ error: 'Conference is not accepting submissions' });
    }

    if (new Date() > new Date(conference.submission_deadline)) {
      return res.status(400).json({ error: 'Submission deadline has passed' });
    }

    // Check submission limits
    if (conference.max_submissions) {
      const submissionCount = await db.query(
        'SELECT COUNT(*) as count FROM papers WHERE corresponding_author_id = $1 AND conference_id = $2 AND status != $3',
        [userId, conferenceId, 'withdrawn']
      );

      if (Number(submissionCount.rows[0].count) >= conference.max_submissions) {
        return res.status(400).json({ 
          error: `Maximum submissions (${conference.max_submissions}) exceeded for this conference` 
        });
      }
    }

    // Validate track if provided
    if (trackId) {
      const trackResult = await db.query(
        'SELECT id FROM conference_tracks WHERE id = $1 AND conference_id = $2',
        [trackId, conferenceId]
      );
      
      if (trackResult.rows.length === 0) {
        return res.status(400).json({ error: 'Invalid track selection' });
      }
    }

    // Validate authors exist
    const authorIds = authors.map((a: any) => a.authorId);
    const usersResult = await db.query(
      `SELECT id, email, first_name, last_name FROM users WHERE id = ANY($1::uuid[])`,
      [authorIds]
    );

    if (usersResult.rows.length !== authorIds.length) {
      return res.status(400).json({ error: 'One or more authors not found' });
    }

    // Check if user is submitting on behalf of others
    const hasNonSelfAuthors = authors.some((a: any) => a.authorId !== userId);
    if (hasNonSelfAuthors) {
      // For now, only allow users to submit papers with themselves as authors
      return res.status(400).json({ 
        error: 'Currently, you can only submit papers with yourself as an author' 
      });
    }

    // Create paper
    const paperResult = await db.query(`
      INSERT INTO papers (
        title, abstract, keywords, conference_id, track_id, corresponding_author_id
      ) VALUES ($1, $2, $3, $4, $5, $6)
      RETURNING *
    `, [title, abstract, keywords, conferenceId, trackId, userId]);

    const paper = paperResult.rows[0];

    // Add authors
    for (const author of authors) {
      await db.query(`
        INSERT INTO paper_authors (paper_id, author_id, is_corresponding_author, author_order)
        VALUES ($1, $2, $3, $4)
      `, [paper.id, author.authorId, author.isCorrespondingAuthor || false, author.authorOrder]);
    }

    // Send confirmation email
    await emailService.sendSubmissionConfirmationEmail((req as any).user, paper, conference);

    res.status(201).json({
      message: 'Paper submitted successfully',
      paper
    });
  } catch (error) {
    console.error('Submit paper error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Update paper (author can update before review starts)
router.put('/:id', [
  authenticate,
  body('title').optional().isLength({ min: 10, max: 500 }).trim().escape(),
  body('abstract').optional().isLength({ min: 50, max: 5000 }).trim(),
  body('keywords').optional().isArray(),
  body('trackId').optional().isUUID()
], async (req, res) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ errors: errors.array() });
    }

    const { id } = req.params;
    const userId = (req as any).user.id;
    const updateData = req.body;

    // Check if paper exists and user is the corresponding author
    const paperResult = await db.query(
      'SELECT * FROM papers WHERE id = $1 AND corresponding_author_id = $2',
      [id, userId]
    );

    if (paperResult.rows.length === 0) {
      return res.status(404).json({ error: 'Paper not found or you are not the corresponding author' });
    }

    const paper = paperResult.rows[0];

    // Check if paper can be updated (not under review yet)
    if (paper.status !== 'submitted' && paper.status !== 'needs_revision') {
      return res.status(400).json({ error: 'Paper cannot be updated at this stage' });
    }

    // Build dynamic update query
    const allowedFields = ['title', 'abstract', 'keywords', 'track_id'];
    const updates: string[] = [];
    const values: any[] = [];
    let paramCount = 1;

    for (const [key, value] of Object.entries(updateData)) {
      if (allowedFields.includes(key)) {
        const dbKey = key.replace(/([A-Z])/g, '_$1').toLowerCase();
        updates.push(`${dbKey} = $${paramCount}`);
        values.push(value);
        paramCount++;
      }
    }

    if (updates.length === 0) {
      return res.status(400).json({ error: 'No valid fields to update' });
    }

    values.push(id); // Add paper ID for WHERE clause

    const result = await db.query(`
      UPDATE papers 
      SET ${updates.join(', ')}, updated_at = CURRENT_TIMESTAMP
      WHERE id = $${paramCount}
      RETURNING *
    `, values);

    res.json({
      message: 'Paper updated successfully',
      paper: result.rows[0]
    });
  } catch (error) {
    console.error('Update paper error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Update paper status (admin only)
router.patch('/:id/status', [
  authenticate,
  requireRole(['admin']),
  body('status').isIn(['submitted', 'under_review', 'accepted', 'rejected', 'needs_revision', 'withdrawn']),
  body('notes').optional().trim()
], async (req, res) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ errors: errors.array() });
    }

    const { id } = req.params;
    const { status, notes } = req.body;

    const result = await db.query(`
      UPDATE papers 
      SET status = $1, 
          notes = COALESCE($2, notes),
          decision_date = CASE WHEN $1 IN ('accepted', 'rejected') THEN CURRENT_TIMESTAMP ELSE decision_date END,
          updated_at = CURRENT_TIMESTAMP
      WHERE id = $3
      RETURNING *
    `, [status, notes, id]);

    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Paper not found' });
    }

    const paper = result.rows[0];

    // Send decision notification if paper is accepted/rejected
    if (status === 'accepted' || status === 'rejected' || status === 'needs_revision') {
      const user = await db.query('SELECT * FROM users WHERE id = $1', [paper.corresponding_author_id]);
      const conference = await db.query('SELECT * FROM conferences WHERE id = $1', [paper.conference_id]);
      
      if (user.rows.length > 0 && conference.rows.length > 0) {
        await emailService.sendDecisionNotificationEmail(
          user.rows[0], 
          paper, 
          status, 
          conference.rows[0]
        );
      }
    }

    res.json({
      message: 'Paper status updated successfully',
      paper
    });
  } catch (error) {
    console.error('Update paper status error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

export default router;