import jwt from 'jsonwebtoken';
import bcrypt from 'bcryptjs';
import { Request, Response, NextFunction } from 'express';
import Database from '../database/connection';

export interface JWTPayload {
  userId: string;
  email: string;
  role: string;
}

export class AuthService {
  private static instance: AuthService;
  private db: Database;

  private constructor() {
    this.db = Database.getInstance();
  }

  public static getInstance(): AuthService {
    if (!AuthService.instance) {
      AuthService.instance = new AuthService();
    }
    return AuthService.instance;
  }

  public async hashPassword(password: string): Promise<string> {
    const saltRounds = 12;
    return await bcrypt.hash(password, saltRounds);
  }

  public async comparePassword(password: string, hash: string): Promise<boolean> {
    return await bcrypt.compare(password, hash);
  }

  public generateToken(payload: JWTPayload): string {
    return jwt.sign(
      payload,
      process.env.JWT_SECRET || 'your-secret-key-change-in-production',
      { expiresIn: '24h' }
    );
  }

  public verifyToken(token: string): JWTPayload | null {
    try {
      return jwt.verify(
        token,
        process.env.JWT_SECRET || 'your-secret-key-change-in-production'
      ) as JWTPayload;
    } catch (error) {
      return null;
    }
  }

  public async authenticateUser(email: string, password: string): Promise<{ user: any; token: string } | null> {
    try {
      const result = await this.db.query(
        `SELECT u.*, 
                COALESCE(
                  array_agg(DISTINCT ucr.role) FILTER (WHERE ucr.role IS NOT NULL),
                  '{}'
                ) as roles
         FROM users u
         LEFT JOIN user_conference_roles ucr ON u.id = ucr.user_id
         WHERE u.email = $1
         GROUP BY u.id`,
        [email]
      );

      if (result.rows.length === 0) {
        return null;
      }

      const user = result.rows[0];
      const isValidPassword = await this.comparePassword(password, user.password_hash);
      
      if (!isValidPassword) {
        return null;
      }

      const token = this.generateToken({
        userId: user.id,
        email: user.email,
        role: user.roles[0] || 'author'
      });

      // Remove sensitive data
      delete user.password_hash;
      delete user.password_reset_token;
      delete user.email_verification_token;

      return { user, token };
    } catch (error) {
      console.error('Authentication error:', error);
      return null;
    }
  }

  public async registerUser(userData: any): Promise<any> {
    try {
      const { email, password, firstName, lastName, affiliation } = userData;
      
      const passwordHash = await this.hashPassword(password);
      
      const result = await this.db.query(
        `INSERT INTO users (email, password_hash, first_name, last_name, affiliation) 
         VALUES ($1, $2, $3, $4, $5) 
         RETURNING id, email, first_name, last_name, affiliation, created_at`,
        [email, passwordHash, firstName, lastName, affiliation]
      );

      return result.rows[0];
    } catch (error) {
      console.error('Registration error:', error);
      throw error;
    }
  }

  public async getUserById(userId: string): Promise<any> {
    try {
      const result = await this.db.query(
        `SELECT u.*, 
                COALESCE(
                  array_agg(DISTINCT ucr.role) FILTER (WHERE ucr.role IS NOT NULL),
                  '{}'
                ) as roles
         FROM users u
         LEFT JOIN user_conference_roles ucr ON u.id = ucr.user_id
         WHERE u.id = $1
         GROUP BY u.id`,
        [userId]
      );

      if (result.rows.length === 0) {
        return null;
      }

      const user = result.rows[0];
      delete user.password_hash;
      delete user.password_reset_token;
      delete user.email_verification_token;

      return user;
    } catch (error) {
      console.error('Get user error:', error);
      return null;
    }
  }

  public async hasRole(userId: string, role: string, conferenceId?: string): Promise<boolean> {
    try {
      if (conferenceId) {
        const result = await this.db.query(
          'SELECT 1 FROM user_conference_roles WHERE user_id = $1 AND conference_id = $2 AND role = $3',
          [userId, conferenceId, role]
        );
        return result.rows.length > 0;
      } else {
        const result = await this.db.query(
          'SELECT 1 FROM user_conference_roles WHERE user_id = $1 AND role = $2',
          [userId, role]
        );
        return result.rows.length > 0;
      }
    } catch (error) {
      console.error('Role check error:', error);
      return false;
    }
  }
}

// Authentication middleware
export const authenticate = async (req: Request, res: Response, next: NextFunction) => {
  const authService = AuthService.getInstance();
  
  try {
    const token = req.header('Authorization')?.replace('Bearer ', '');
    
    if (!token) {
      return res.status(401).json({ error: 'Access denied. No token provided.' });
    }

    const payload = authService.verifyToken(token);
    
    if (!payload) {
      return res.status(401).json({ error: 'Invalid token.' });
    }

    const user = await authService.getUserById(payload.userId);
    
    if (!user) {
      return res.status(401).json({ error: 'User not found.' });
    }

    (req as any).user = user;
    (req as any).userId = user.id;
    next();
  } catch (error) {
    console.error('Authentication middleware error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
};

// Role-based authorization middleware
export const requireRole = (roles: string[], conferenceId?: string) => {
  return async (req: Request, res: Response, next: NextFunction) => {
    const authService = AuthService.getInstance();
    const user = (req as any).user;
    
    if (!user) {
      return res.status(401).json({ error: 'Authentication required.' });
    }

    try {
      const hasRequiredRole = await Promise.all(
        roles.map(role => authService.hasRole(user.id, role, conferenceId))
      );
      
      if (!hasRequiredRole.some(Boolean)) {
        return res.status(403).json({ error: 'Insufficient permissions.' });
      }
      
      next();
    } catch (error) {
      console.error('Role authorization error:', error);
      res.status(500).json({ error: 'Internal server error' });
    }
  };
};